<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Products extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $products = $db->table('products')
            ->select('products.*, categories.nama_kategori')
            ->join(
                'categories',
                'categories.id = products.category_id',
                'left'
            )
            ->orderBy('products.id', 'DESC')
            ->get()
            ->getResultArray();

        return view('products/index', [
            'products' => $products
        ]);
    }

    public function create()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $categories = $db->table('categories')
            ->get()
            ->getResultArray();

        return view('products/form', [
            'categories' => $categories,
            'product' => null
        ]);
    }

    public function store()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $validation = \Config\Services::validation();

        $validation->setRules([
            'nama_produk' => 'required|max_length[150]',
            'harga' => 'required|numeric|greater_than_equal_to[0]',
            'category_id' => 'permit_empty|is_natural_no_zero'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode(' ', $validation->getErrors()));
        }

        $foto = $this->request->getFile('foto');
        $namaFoto = null;

        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            if (!in_array($foto->getExtension(), ['jpg', 'jpeg', 'png', 'webp'])) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Format foto harus JPG, PNG, atau WEBP.');
            }

            if ($foto->getSizeByUnit('mb') > 3) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Ukuran foto maksimal 3 MB.');
            }

            $namaFoto = $foto->getRandomName();
            $foto->move(FCPATH . 'uploads/products', $namaFoto);
        }

        $db = \Config\Database::connect();

        $db->table('products')->insert([
            'category_id' => $this->request->getPost('category_id') ?: null,
            'nama_produk' => $this->request->getPost('nama_produk'),
            'deskripsi' => $this->request->getPost('deskripsi'),
            'harga' => $this->request->getPost('harga'),
            'foto' => $namaFoto,
            'is_active' => 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/products')
            ->with('success', 'Produk berhasil ditambahkan!');
    }

    public function edit($id)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $product = $db->table('products')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (!$product) {
            return redirect()->to('/products')
                ->with('error', 'Produk tidak ditemukan.');
        }

        $categories = $db->table('categories')
            ->get()
            ->getResultArray();

        return view('products/form', [
            'categories' => $categories,
            'product' => $product
        ]);
    }

    public function update($id)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $product = $db->table('products')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (!$product) {
            return redirect()->to('/products');
        }

        $namaFoto = $product['foto'];
        $foto = $this->request->getFile('foto');

        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            if (!in_array($foto->getExtension(), ['jpg', 'jpeg', 'png', 'webp'])) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Format foto harus JPG, PNG, atau WEBP.');
            }

            if ($foto->getSizeByUnit('mb') > 3) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Ukuran foto maksimal 3 MB.');
            }

            $namaFoto = $foto->getRandomName();
            $foto->move(FCPATH . 'uploads/products', $namaFoto);

            if ($product['foto'] && is_file(FCPATH . 'uploads/products/' . $product['foto'])) {
                unlink(FCPATH . 'uploads/products/' . $product['foto']);
            }
        }

        $db->table('products')
            ->where('id', $id)
            ->update([
                'category_id' => $this->request->getPost('category_id') ?: null,
                'nama_produk' => $this->request->getPost('nama_produk'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'harga' => $this->request->getPost('harga'),
                'foto' => $namaFoto,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

        return redirect()->to('/products')
            ->with('success', 'Produk berhasil diperbarui!');
    }

    public function delete($id)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $product = $db->table('products')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if ($product) {
            if ($product['foto'] && is_file(FCPATH . 'uploads/products/' . $product['foto'])) {
                unlink(FCPATH . 'uploads/products/' . $product['foto']);
            }

            $db->table('products')
                ->where('id', $id)
                ->delete();
        }

        return redirect()->to('/products')
            ->with('success', 'Produk berhasil dihapus!');
    }
}