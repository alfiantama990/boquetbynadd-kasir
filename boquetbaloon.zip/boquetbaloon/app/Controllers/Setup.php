<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Setup extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();

        $jumlahUser = $db->table('users')->countAll();

        if ($jumlahUser > 0) {
            return redirect()->to('/login')
                ->with('error', 'Akun sudah dibuat. Silakan login.');
        }

        return view('auth/setup');
    }

    public function create()
    {
        $db = \Config\Database::connect();

        $jumlahUser = $db->table('users')->countAll();

        if ($jumlahUser > 0) {
            return redirect()->to('/login');
        }

        $nama = trim($this->request->getPost('nama_lengkap'));
        $username = trim($this->request->getPost('username'));
        $password = $this->request->getPost('password');
        $konfirmasi = $this->request->getPost('konfirmasi_password');

        if (!$nama || !$username || !$password) {
            return redirect()->back()
                ->with('error', 'Semua kolom wajib diisi.');
        }

        if ($password !== $konfirmasi) {
            return redirect()->back()
                ->with('error', 'Konfirmasi password tidak cocok.');
        }

        if (strlen($password) < 8) {
            return redirect()->back()
                ->with('error', 'Password minimal 8 karakter.');
        }

        $db->table('users')->insert([
            'nama_lengkap' => $nama,
            'username'     => $username,
            'password'     => password_hash($password, PASSWORD_DEFAULT),
            'role'         => 'admin',
            'is_active'    => 1,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/login')
            ->with('success', 'Admin berhasil dibuat. Silakan login.');
    }
}