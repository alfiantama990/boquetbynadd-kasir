<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Cashier extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $products = $db->table('products')
            ->where('is_active', 1)
            ->orderBy('nama_produk', 'ASC')
            ->get()
            ->getResultArray();

        return view('cashier/index', [
            'products' => $products
        ]);
    }

    public function store()
    {
        if (!session()->get('isLoggedIn')) {
            if ($this->request->isAJAX()) {
                return $this->response->setStatusCode(401)->setJSON([
                    'status' => 'error',
                    'message' => 'Sesi login telah berakhir. Silakan login kembali.',
                ]);
            }
            return redirect()->to('/login');
        }

        $productIds = $this->request->getPost('product_id');
        $quantities = $this->request->getPost('quantity');

        if (!is_array($productIds) || !is_array($quantities)
            || count($productIds) === 0
            || count($productIds) !== count($quantities)) {
            if ($this->request->isAJAX()) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Keranjang masih kosong atau tidak valid.',
                    'csrf_name' => csrf_token(),
                    'csrf_hash' => csrf_hash(),
                ]);
            }
            return redirect()->back()
                ->with('error', 'Keranjang masih kosong atau tidak valid.');
        }

        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            $items = [];
            $total = 0;

            foreach ($productIds as $index => $id) {
                $id = (int) $id;
                $qty = filter_var($quantities[$index], FILTER_VALIDATE_INT);

                if ($id < 1 || $qty === false || $qty < 1 || $qty > 1000) {
                    throw new \Exception('Produk atau jumlah tidak valid.');
                }

                $product = $db->table('products')
                    ->where('id', $id)
                    ->where('is_active', 1)
                    ->get()
                    ->getRowArray();

                if (!$product) {
                    throw new \Exception('Ada produk yang tidak tersedia.');
                }

                $subtotal = (float) $product['harga'] * $qty;
                $total += $subtotal;

                $items[] = [
                    'product_id' => $product['id'],
                    'product_name' => $product['nama_produk'],
                    'price' => $product['harga'],
                    'quantity' => $qty,
                    'subtotal' => $subtotal
                ];
            }

            $discount = (float) $this->request->getPost('discount');
            $paid = (float) $this->request->getPost('paid_amount');
            $method = $this->request->getPost('payment_method');

            if (!is_finite($discount) || !is_finite($paid)
                || $discount < 0 || $discount > $total) {
                throw new \Exception('Diskon atau pembayaran tidak valid.');
            }

            if (!in_array($method, ['cash', 'transfer', 'qris'], true)) {
                throw new \Exception('Metode pembayaran tidak valid.');
            }

            $grandTotal = $total - $discount;

            if ($paid < $grandTotal) {
                throw new \Exception('Nominal pembayaran kurang.');
            }

            if ($method !== 'cash' && $paid != $grandTotal) {
                throw new \Exception('Pembayaran non-tunai harus sesuai total.');
            }

            $invoice = 'BB-' . date('YmdHis') . '-' . random_int(100, 999);
            $customerName = trim($this->request->getPost('customer_name') ?? '');
            $createdAt = date('Y-m-d H:i:s');
            $changeAmount = $paid - $grandTotal;

            $saleData = [
                'invoice_no' => $invoice,
                'user_id' => session()->get('user_id'),
                'customer_name' => $customerName,
                'total' => $total,
                'discount' => $discount,
                'grand_total' => $grandTotal,
                'payment_method' => $method,
                'paid_amount' => $paid,
                'change_amount' => $changeAmount,
                'created_at' => $createdAt
            ];

            $db->table('sales')->insert($saleData);

            $saleId = $db->insertID();

            foreach ($items as $item) {
                $item['sale_id'] = $saleId;
                $item['created_at'] = $createdAt;

                $db->table('sale_items')->insert($item);
            }

            if ($db->transStatus() === false) {
                throw new \Exception('Transaksi gagal disimpan.');
            }

            $db->transCommit();

            if ($this->request->isAJAX()) {
                $saleData['id'] = $saleId;
                return $this->response->setJSON([
                    'status' => 'ok',
                    'sale' => $saleData,
                    'items' => $items,
                    'cashier' => session()->get('nama_lengkap') ?? '',
                    'redirect_url' => site_url('cashier/success/' . $saleId),
                    'csrf_name' => csrf_token(),
                    'csrf_hash' => csrf_hash(),
                ]);
            }

            return redirect()->to('/cashier/success/' . $saleId);

        } catch (\Throwable $e) {
            $db->transRollback();

            if ($this->request->isAJAX()) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => $e->getMessage(),
                    'csrf_name' => csrf_token(),
                    'csrf_hash' => csrf_hash(),
                ]);
            }

            return redirect()->back()
                ->with('error', $e->getMessage());
        }
    }

    public function success($id)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();

        $sale = $db->table('sales')
            ->select('sales.*, users.nama_lengkap')
            ->join('users', 'users.id = sales.user_id', 'left')
            ->where('sales.id', $id)
            ->get()
            ->getRowArray();

        if (!$sale) {
            return redirect()->to('/cashier');
        }

        $items = $db->table('sale_items')
            ->where('sale_id', $id)
            ->get()
            ->getResultArray();

        return view('cashier/success', [
            'sale' => $sale,
            'items' => $items
        ]);
    }
}