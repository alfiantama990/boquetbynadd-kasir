<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('login'));
        }

        $db = \Config\Database::connect();

        $hariIni = date('Y-m-d');
        $tanggalAwal = date('Y-m-d', strtotime('-6 days'));

        // Omzet hari ini
        $omzetHariIni = $db->table('sales')
            ->selectSum('grand_total')
            ->where('DATE(created_at)', $hariIni)
            ->get()
            ->getRowArray();

        // Jumlah transaksi hari ini
        $transaksiHariIni = $db->table('sales')
            ->where('DATE(created_at)', $hariIni)
            ->countAllResults();

        // Jumlah produk aktif
        $produkAktif = $db->table('products')
            ->where('is_active', 1)
            ->countAllResults();

        // Jumlah pelanggan unik yang pernah bertransaksi
        $pelanggan = $db->table('sales')
            ->where('customer_name IS NOT NULL', null, false)
            ->where('customer_name !=', '')
            ->select('COUNT(DISTINCT customer_name) AS jumlah')
            ->get()
            ->getRowArray();

        // Data grafik penjualan 7 hari terakhir
        $dataGrafik = $db->table('sales')
            ->select('DATE(created_at) AS tanggal, SUM(grand_total) AS omzet')
            ->where('DATE(created_at) >=', $tanggalAwal)
            ->where('DATE(created_at) <=', $hariIni)
            ->groupBy('DATE(created_at)')
            ->orderBy('tanggal', 'ASC')
            ->get()
            ->getResultArray();

        $grafik = [];

        for ($i = 6; $i >= 0; $i--) {
            $tanggal = date('Y-m-d', strtotime("-$i days"));

            $grafik[$tanggal] = 0;
        }

        foreach ($dataGrafik as $data) {
            $grafik[$data['tanggal']] = (float) $data['omzet'];
        }

        // Lima produk terlaris
        $produkTerlaris = $db->table('sale_items')
            ->select('product_name, SUM(quantity) AS total_terjual')
            ->groupBy('product_name')
            ->orderBy('total_terjual', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();

        return view('dashboard/index', [
            'omzetHariIni' => $omzetHariIni['grand_total'] ?? 0,
            'transaksiHariIni' => $transaksiHariIni,
            'produkAktif' => $produkAktif,
            'jumlahPelanggan' => $pelanggan['jumlah'] ?? 0,
            'grafikLabels' => array_map(
                fn($tanggal) => date('d/m', strtotime($tanggal)),
                array_keys($grafik)
            ),
            'grafikData' => array_values($grafik),
            'produkTerlaris' => $produkTerlaris
        ]);
    }
}