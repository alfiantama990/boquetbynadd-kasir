<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Transaksi Berhasil</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            font-family: Arial, sans-serif;
        }

        .receipt {
            background: white;
            max-width: 500px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 5px 25px rgba(217,139,170,.12);
        }

        .pink {
            color: #D98BAA;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                background: white;
            }

            .receipt {
                box-shadow: none;
                margin: 0 auto;
            }
        }
    </style>
</head>

<body>

<div class="receipt">

    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3 no-print">
        <button type="button"
                class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-2"
                data-bp-open-modal
                data-bp-status-btn>
            <span data-bp-status-dot style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block;"></span>
            <span data-bp-status-label>Hubungkan Printer</span>
        </button>

        <button type="button"
                class="btn btn-sm text-white"
                style="background:#D98BAA;"
                data-bp-quick-scan>
            ⚡ Scan Cepat
        </button>
    </div>

    <div class="text-center mb-4">

        <h3 class="pink">🌸 BoquetBaloon</h3>

        <h5 class="text-success">✓ Transaksi Berhasil</h5>

        <small class="text-muted">
            <?= esc($sale['invoice_no']) ?>
        </small>

    </div>

    <hr>

    <div class="d-flex justify-content-between">
        <span>Tanggal</span>
        <strong><?= esc($sale['created_at']) ?></strong>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Pelanggan</span>
        <strong><?= esc($sale['customer_name'] ?: 'Umum') ?></strong>
    </div>

    <hr>

    <?php foreach ($items as $item): ?>

        <div class="mb-3">
            <strong><?= esc($item['product_name']) ?></strong>

            <div class="d-flex justify-content-between">
                <small>
                    <?= $item['quantity'] ?> x
                    Rp <?= number_format($item['price'], 0, ',', '.') ?>
                </small>

                <strong>
                    Rp <?= number_format($item['subtotal'], 0, ',', '.') ?>
                </strong>
            </div>
        </div>

    <?php endforeach; ?>

    <hr>

    <div class="d-flex justify-content-between">
        <span>Subtotal</span>
        <strong>Rp <?= number_format($sale['total'], 0, ',', '.') ?></strong>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Diskon</span>
        <strong>Rp <?= number_format($sale['discount'], 0, ',', '.') ?></strong>
    </div>

    <div class="d-flex justify-content-between mt-3">
        <h5>Total</h5>
        <h5 class="pink">
            Rp <?= number_format($sale['grand_total'], 0, ',', '.') ?>
        </h5>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Metode Pembayaran</span>
        <strong><?= strtoupper(esc($sale['payment_method'])) ?></strong>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Dibayar</span>
        <strong>Rp <?= number_format($sale['paid_amount'], 0, ',', '.') ?></strong>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Kembalian</span>
        <strong>Rp <?= number_format($sale['change_amount'], 0, ',', '.') ?></strong>
    </div>

    <hr>

    <p class="text-center text-muted">
        Terima kasih sudah berbelanja! 💗
    </p>

    <div class="d-grid gap-2 no-print">

        <button type="button" id="btnDirectPrintSuccess" class="btn btn-success">
            ⚡ Direct Print Struk (58mm)
        </button>

        <button onclick="window.print()" class="btn btn-outline-secondary">
            Cetak Struk (Browser)
        </button>

        <a href="<?= site_url('cashier') ?>"
           class="btn"
           style="background:#D98BAA;color:white;">
            Transaksi Baru
        </a>

    </div>

</div>

<?= view('partials/printer_scanner', ['autoReconnectPrinter' => true]) ?>

<script>
    const SUCCESS_SALE_RECEIPT = {
        orderId: <?= json_encode($sale['invoice_no']) ?>,
        date: <?= json_encode(date('d/m/Y H:i', strtotime($sale['created_at']))) ?>,
        customerName: <?= json_encode($sale['customer_name'] ?: 'Umum') ?>,
        cashier: <?= json_encode($sale['nama_lengkap'] ?? session()->get('nama_lengkap') ?? '') ?>,
        items: <?= json_encode(array_map(static function ($item) {
            return [
                'name' => $item['product_name'],
                'qty' => (int) $item['quantity'],
                'price' => (float) $item['price'],
                'subtotal' => (float) $item['subtotal'],
            ];
        }, $items)) ?>,
        subtotal: <?= (float) $sale['total'] ?>,
        discount: <?= (float) $sale['discount'] ?>,
        total: <?= (float) $sale['grand_total'] ?>,
        paymentMethod: <?= json_encode($sale['payment_method']) ?>,
        paid: <?= (float) $sale['paid_amount'] ?>,
        change: <?= (float) $sale['change_amount'] ?>
    };

    document.getElementById('btnDirectPrintSuccess').addEventListener('click', async function () {
        if (!window.BoquetPrinter) return;
        const btn = this;
        const originalText = btn.innerHTML;
        btn.disabled = true;

        try {
            if (!window.BoquetPrinter.isConnected()) {
                const info = await window.BoquetPrinter.scanAndConnect('all');
                if (!info) return;
            }
            btn.innerHTML = 'Mencetak 58mm...';
            await window.BoquetPrinter.printSaleReceipt(SUCCESS_SALE_RECEIPT);
        } catch (err) {
            window.BoquetPrinter.showToast(err.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    });
</script>

</body>
</html>