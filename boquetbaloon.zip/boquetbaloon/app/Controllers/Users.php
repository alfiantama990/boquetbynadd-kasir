<?php

namespace App\Controllers;

class Users extends BaseController
{
    private function checkAdmin()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('login'));
        }

        if (session()->get('role') !== 'admin') {
            return redirect()->to(site_url('dashboard'))
                ->with('error', 'Anda tidak memiliki akses ke halaman ini.');
        }

        return null;
    }

    public function index()
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        $users = \Config\Database::connect()
            ->table('users')
            ->orderBy('id', 'DESC')
            ->get()
            ->getResultArray();

        return view('users/index', [
            'users' => $users
        ]);
    }

    public function create()
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        return view('users/form', [
            'user' => null
        ]);
    }

    public function store()
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'nama_lengkap' => 'required|max_length[100]',
            'password' => 'required|min_length[6]',
            'role' => 'required|in_list[admin,kasir]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        \Config\Database::connect()->table('users')->insert([
            'username' => trim($this->request->getPost('username')),
            'nama_lengkap' => trim($this->request->getPost('nama_lengkap')),
            'password' => password_hash(
                $this->request->getPost('password'),
                PASSWORD_DEFAULT
            ),
            'role' => $this->request->getPost('role'),
            'is_active' => 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to(site_url('users'))
            ->with('success', 'Pengguna berhasil ditambahkan.');
    }

    public function edit($id)
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        $user = \Config\Database::connect()
            ->table('users')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (!$user) {
            return redirect()->to(site_url('users'))
                ->with('error', 'Pengguna tidak ditemukan.');
        }

        return view('users/form', [
            'user' => $user
        ]);
    }

    public function update($id)
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        $db = \Config\Database::connect();

        $user = $db->table('users')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (!$user) {
            return redirect()->to(site_url('users'))
                ->with('error', 'Pengguna tidak ditemukan.');
        }

        $rules = [
            'username' => "required|min_length[3]|max_length[50]|is_unique[users.username,id,{$id}]",
            'nama_lengkap' => 'required|max_length[100]',
            'role' => 'required|in_list[admin,kasir]'
        ];

        $password = $this->request->getPost('password');

        if ($password !== '') {
            $rules['password'] = 'min_length[6]';
        }

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = [
            'username' => trim($this->request->getPost('username')),
            'nama_lengkap' => trim($this->request->getPost('nama_lengkap')),
            'role' => $this->request->getPost('role'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($password !== '') {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $db->table('users')
            ->where('id', $id)
            ->update($data);

        // Perbarui session jika Admin mengedit akun miliknya sendiri.
        if ((int) session()->get('user_id') === (int) $id) {
            session()->set([
                'username' => $data['username'],
                'nama_lengkap' => $data['nama_lengkap'],
                'role' => $data['role']
            ]);
        }

        return redirect()->to(site_url('users'))
            ->with('success', 'Data pengguna berhasil diperbarui.');
    }

    public function delete($id)
    {
        if ($redirect = $this->checkAdmin()) {
            return $redirect;
        }

        if ((int) session()->get('user_id') === (int) $id) {
            return redirect()->to(site_url('users'))
                ->with('error', 'Anda tidak dapat menonaktifkan akun sendiri.');
        }

        $db = \Config\Database::connect();

        $user = $db->table('users')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (!$user) {
            return redirect()->to(site_url('users'))
                ->with('error', 'Pengguna tidak ditemukan.');
        }

        // Nonaktifkan akun, jangan hapus agar riwayat transaksi tetap aman.
        $db->table('users')
            ->where('id', $id)
            ->update([
                'is_active' => 0,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

        return redirect()->to(site_url('users'))
            ->with('success', 'Akun berhasil dinonaktifkan.');
    }
}