<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
// ROUTE SETUP ADMIN
$routes->get('setup', 'Setup::index');
$routes->post('setup/create', 'Setup::create');

// ROUTE LOGIN
$routes->get('login', 'Auth::index');
$routes->post('login/process', 'Auth::process');
$routes->get('logout', 'Auth::logout');

// Dashboard
$routes->get('dashboard', 'Dashboard::index');

// PRODUK
$routes->get('products', 'Products::index');
$routes->get('products/create', 'Products::create');
$routes->post('products/store', 'Products::store');
$routes->get('products/edit/(:num)', 'Products::edit/$1');
$routes->post('products/update/(:num)', 'Products::update/$1');
$routes->post('products/delete/(:num)', 'Products::delete/$1');

// KASIR / TRANSAKSI
$routes->get('cashier', 'Cashier::index');
$routes->post('cashier/store', 'Cashier::store');
$routes->get('cashier/success/(:num)', 'Cashier::success/$1');

$routes->get('sales', 'Sales::index');
$routes->get('sales/detail/(:num)', 'Sales::detail/$1');

$routes->get('users', 'Users::index');
$routes->get('users/create', 'Users::create');
$routes->post('users/store', 'Users::store');
$routes->get('users/edit/(:num)', 'Users::edit/$1');
$routes->post('users/update/(:num)', 'Users::update/$1');
$routes->post('users/delete/(:num)', 'Users::delete/$1');