/**
 * Known BLE GATT Service UUIDs used by common thermal printers
 * (EPPOS RPP02, Xprinter, Zjiang, Goojprt, Panda, Iware, Rongta, Star, etc.)
 */
export const THERMAL_PRINTER_SERVICE_UUIDS = [
  '000018f0-0000-1000-8000-00805f9b34fb', // Generic BLE Thermal Printer (RPP02, ZJ, Xprinter)
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2', // Star / RPP02 / POS Printer service
  '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC / Microchip BLE UART (common in EPPOS/RPP02)
  '0000ff00-0000-1000-8000-00805f9b34fb', // Goojprt / BellaV / generic thermal printer
  '0000ffe0-0000-1000-8000-00805f9b34fb', // HM-10 / JDY BLE Serial bridge
  '0000ae30-0000-1000-8000-00805f9b34fb', // Rongta / Bixolon / generic POS
  'bef8d6c9-9c21-4c9e-b632-bd58c1009f9f', // Generic BLE POS service
  '0000fee7-0000-1000-8000-00805f9b34fb', // Chinese BLE printer service
  '00001800-0000-1000-8000-00805f9b34fb',
  '00001801-0000-1000-8000-00805f9b34fb',
  '0000180a-0000-1000-8000-00805f9b34fb',
];

/**
 * Common name prefixes advertised by Bluetooth thermal printers.
 */
export const THERMAL_PRINTER_NAME_PREFIXES = [
  'RPP',
  'EPPOS',
  'XP-',
  'Xprinter',
  'ZJ-',
  'MTP',
  'MPT',
  'PT-',
  'Printer',
  'BlueTooth Printer',
  'POS',
  'IWARE',
  'PANDA',
  'GOOJPRT',
  'TM-',
  'TSP',
  'BT-',
  'InnerPrinter',
];

const STORAGE_KEY = 'boquetbaloon_bt_printer_last_device';

/**
 * BluetoothPrinterScanner
 * Reusable Web Bluetooth scanner and direct-print controller for websites.
 */
export class BluetoothPrinterScanner {
  constructor(options = {}) {
    this.device = null;
    this.server = null;
    this.service = null;
    this.characteristic = null;
    this.transportType = null; // 'bluetooth' | 'serial'
    this.serialPort = null;

    this.chunkSize = options.chunkSize || 100;
    this.chunkDelayMs = options.chunkDelayMs ?? 20;
    this.onStatusChange = options.onStatusChange || (() => {});
    this.onLog = options.onLog || (() => {});

    this._handleDisconnected = this._handleDisconnected.bind(this);
  }

  /**
   * Check browser and security context support for Web Bluetooth & Web Serial.
   */
  static checkSupport() {
    const isSecure = typeof window !== 'undefined' && window.isSecureContext;
    const hasBluetooth = typeof navigator !== 'undefined' && 'bluetooth' in navigator;
    const hasSerial = typeof navigator !== 'undefined' && 'serial' in navigator;

    return {
      isSecure,
      hasBluetooth,
      hasSerial,
      canAutoReconnect: hasBluetooth && typeof navigator.bluetooth.getDevices === 'function',
    };
  }

  get isConnected() {
    if (this.transportType === 'bluetooth') {
      return Boolean(this.device?.gatt?.connected && this.characteristic);
    }
    if (this.transportType === 'serial') {
      return Boolean(this.serialPort?.writable);
    }
    return false;
  }

  get deviceInfo() {
    if (this.transportType === 'bluetooth' && this.device) {
      return {
        connected: this.isConnected,
        transport: 'Bluetooth (BLE)',
        name: this.device.name || 'Printer Bluetooth',
        id: this.device.id,
        serviceUuid: this.service?.uuid || '-',
        characteristicUuid: this.characteristic?.uuid || '-',
        writeMode: this.characteristic?.properties?.writeWithoutResponse
          ? 'writeWithoutResponse'
          : 'writeWithResponse',
      };
    }
    if (this.transportType === 'serial' && this.serialPort) {
      const info = this.serialPort.getInfo ? this.serialPort.getInfo() : {};
      return {
        connected: this.isConnected,
        transport: 'USB / Serial COM',
        name: info.usbProductId
          ? `USB/COM Printer (VID:${info.usbVendorId} PID:${info.usbProductId})`
          : 'Serial / COM Printer',
        id: 'serial-port',
        serviceUuid: '-',
        characteristicUuid: '-',
        writeMode: 'Serial Stream',
      };
    }
    return {
      connected: false,
      transport: '-',
      name: 'Belum tersambung',
      id: '-',
      serviceUuid: '-',
      characteristicUuid: '-',
      writeMode: '-',
    };
  }

  log(message, level = 'info') {
    const time = new Date().toLocaleTimeString('id-ID', { hour12: false });
    this.onLog({ time, level, message });
  }

  emitStatus() {
    this.onStatusChange(this.deviceInfo);
  }

  _saveLastDeviceMeta(device) {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          id: device.id,
          name: device.name || 'Printer Bluetooth',
          savedAt: Date.now(),
        })
      );
    } catch {
      // Ignore storage errors
    }
  }

  getSavedDeviceMeta() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  /**
   * Open browser's Web Bluetooth scanner dialog and connect to selected printer.
   * @param {Object} params
   * @param {'all'|'thermal'} params.filterMode
   * @param {string[]} params.extraServiceUuids
   */
  async scanAndConnect({ filterMode = 'all', extraServiceUuids = [] } = {}) {
    const support = BluetoothPrinterScanner.checkSupport();
    if (!support.isSecure) {
      throw new Error(
        'Web Bluetooth hanya berjalan di HTTPS atau localhost. Buka halaman ini melalui http://localhost/ atau https://.'
      );
    }
    if (!support.hasBluetooth) {
      throw new Error(
        'Browser ini tidak mendukung Web Bluetooth. Gunakan Google Chrome, Microsoft Edge, atau Opera.'
      );
    }

    const optionalServices = Array.from(
      new Set([...THERMAL_PRINTER_SERVICE_UUIDS, ...extraServiceUuids])
    );

    const requestOptions =
      filterMode === 'thermal'
        ? {
            filters: [
              ...THERMAL_PRINTER_SERVICE_UUIDS.slice(0, 6).map((uuid) => ({ services: [uuid] })),
              ...THERMAL_PRINTER_NAME_PREFIXES.map((namePrefix) => ({ namePrefix })),
            ],
            optionalServices,
          }
        : {
            acceptAllDevices: true,
            optionalServices,
          };

    this.log(`Membuka scanner Bluetooth (mode: ${filterMode})...`);

    const device = await navigator.bluetooth.requestDevice(requestOptions);
    this.log(`Perangkat dipilih: ${device.name || 'Unnamed'} (${device.id})`);

    return this.connectToBluetoothDevice(device);
  }

  /**
   * Connect to a BluetoothDevice and discover its writable characteristic.
   */
  async connectToBluetoothDevice(device) {
    if (this.isConnected) {
      await this.disconnect();
    }

    this.device = device;
    this.transportType = 'bluetooth';
    this.device.removeEventListener('gattserverdisconnected', this._handleDisconnected);
    this.device.addEventListener('gattserverdisconnected', this._handleDisconnected);

    this.log(`Menghubungkan ke GATT server ${device.name || device.id}...`);
    this.server = await device.gatt.connect();

    this.log('Mencari Primary Services & Writable Characteristic...');
    const { service, characteristic } = await this._discoverWritableCharacteristic(this.server);

    this.service = service;
    this.characteristic = characteristic;
    this._saveLastDeviceMeta(device);

    this.log(
      `Terhubung! Service: ${service.uuid} | Characteristic: ${characteristic.uuid}`,
      'success'
    );
    this.emitStatus();
    return this.deviceInfo;
  }

  /**
   * Attempt silent reconnection using navigator.bluetooth.getDevices().
   */
  async tryAutoReconnect() {
    const support = BluetoothPrinterScanner.checkSupport();
    if (!support.canAutoReconnect) {
      throw new Error('Browser tidak mendukung auto-reconnect navigator.bluetooth.getDevices().');
    }

    const saved = this.getSavedDeviceMeta();
    const permittedDevices = await navigator.bluetooth.getDevices();
    if (!permittedDevices.length) {
      throw new Error('Belum ada perangkat printer yang pernah dipasangkan di browser ini.');
    }

    const target =
      (saved && permittedDevices.find((d) => d.id === saved.id)) || permittedDevices[0];
    this.log(`Mencoba auto-reconnect ke ${target.name || target.id}...`);
    return this.connectToBluetoothDevice(target);
  }

  /**
   * Alternative connection via Web Serial API (USB cable or Windows Bluetooth SPP COM port).
   */
  async connectSerial({ baudRate = 9600 } = {}) {
    const support = BluetoothPrinterScanner.checkSupport();
    if (!support.hasSerial) {
      throw new Error('Browser tidak mendukung Web Serial API. Gunakan Chrome/Edge desktop.');
    }
    if (this.isConnected) {
      await this.disconnect();
    }

    this.log('Membuka pemilih Port Serial / USB...');
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate });

    this.serialPort = port;
    this.transportType = 'serial';
    this.log(`Port Serial terbuka (${baudRate} bps).`, 'success');
    this.emitStatus();
    return this.deviceInfo;
  }

  /**
   * Inspect all primary services and pick the best writable GATT characteristic.
   */
  async _discoverWritableCharacteristic(server) {
    let services = [];
    try {
      services = await server.getPrimaryServices();
    } catch (err) {
      for (const uuid of THERMAL_PRINTER_SERVICE_UUIDS) {
        try {
          const svc = await server.getPrimaryService(uuid);
          services.push(svc);
        } catch {
          // Ignore unavailable service
        }
      }
      if (!services.length) {
        throw err;
      }
    }

    const priorityOrder = new Map(
      THERMAL_PRINTER_SERVICE_UUIDS.map((uuid, idx) => [uuid.toLowerCase(), idx])
    );
    services.sort((a, b) => {
      const pa = priorityOrder.has(a.uuid.toLowerCase()) ? priorityOrder.get(a.uuid.toLowerCase()) : 999;
      const pb = priorityOrder.has(b.uuid.toLowerCase()) ? priorityOrder.get(b.uuid.toLowerCase()) : 999;
      return pa - pb;
    });

    let fallbackWritable = null;

    for (const service of services) {
      let characteristics = [];
      try {
        characteristics = await service.getCharacteristics();
      } catch {
        continue;
      }

      for (const char of characteristics) {
        const props = char.properties;
        this.log(
          `  Inspect ${service.uuid.slice(0, 8)}.. -> ${char.uuid.slice(0, 8)}.. [write=${props.write}, writeNoResp=${props.writeWithoutResponse}]`
        );

        if (props.writeWithoutResponse) {
          return { service, characteristic: char };
        }
        if (props.write && !fallbackWritable) {
          fallbackWritable = { service, characteristic: char };
        }
      }
    }

    if (fallbackWritable) {
      return fallbackWritable;
    }

    throw new Error(
      'Perangkat terhubung tetapi tidak ditemukan GATT Characteristic yang bisa ditulis. Pastikan printer mendukung BLE atau gunakan mode USB / Serial COM Port.'
    );
  }

  /**
   * Send raw ESC/POS bytes to the connected printer in safe BLE chunks.
   */
  async printRaw(bytes, options = {}) {
    if (!this.isConnected) {
      throw new Error('Printer belum tersambung. Silakan scan & sambungkan printer terlebih dahulu.');
    }

    const payload = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);

    if (this.transportType === 'serial') {
      const writer = this.serialPort.writable.getWriter();
      try {
        await writer.write(payload);
        this.log(`Berhasil mengirim ${payload.length} byte via Serial/USB.`, 'success');
      } finally {
        writer.releaseLock();
      }
      return;
    }

    let chunkSize = options.chunkSize || this.chunkSize;
    const delayMs = options.delayMs ?? this.chunkDelayMs;

    this.log(`Mengirim ${payload.length} byte ke printer (chunk ${chunkSize} byte)...`);

    try {
      await this._writeChunks(payload, chunkSize, delayMs);
    } catch (err) {
      if (chunkSize > 20) {
        this.log(
          `Chunk ${chunkSize} byte gagal (${err.message}). Mencoba ulang dengan MTU aman 20 byte...`,
          'warn'
        );
        chunkSize = 20;
        await this._writeChunks(payload, 20, Math.max(25, delayMs));
      } else {
        throw err;
      }
    }

    this.log(`Print selesai (${payload.length} byte terkirim).`, 'success');
  }

  async _writeChunks(payload, chunkSize, delayMs) {
    const canWriteNoResp = Boolean(this.characteristic.properties.writeWithoutResponse);

    for (let offset = 0; offset < payload.length; offset += chunkSize) {
      const chunk = payload.slice(offset, offset + chunkSize);

      if (canWriteNoResp && typeof this.characteristic.writeValueWithoutResponse === 'function') {
        await this.characteristic.writeValueWithoutResponse(chunk);
      } else if (typeof this.characteristic.writeValueWithResponse === 'function') {
        await this.characteristic.writeValueWithResponse(chunk);
      } else {
        await this.characteristic.writeValue(chunk);
      }

      if (delayMs > 0 && offset + chunkSize < payload.length) {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }

  async disconnect() {
    if (this.transportType === 'bluetooth' && this.device) {
      this.device.removeEventListener('gattserverdisconnected', this._handleDisconnected);
      if (this.device.gatt?.connected) {
        this.device.gatt.disconnect();
      }
    }

    if (this.transportType === 'serial' && this.serialPort) {
      try {
        await this.serialPort.close();
      } catch {
        // Ignore close error
      }
    }

    this.device = null;
    this.server = null;
    this.service = null;
    this.characteristic = null;
    this.serialPort = null;
    this.transportType = null;

    this.log('Koneksi printer diputus.');
    this.emitStatus();
  }

  _handleDisconnected() {
    this.log('Printer terputus dari koneksi Bluetooth.', 'warn');
    this.server = null;
    this.service = null;
    this.characteristic = null;
    this.emitStatus();
  }
}
