<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Buat Admin - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: Arial, sans-serif;
        }

        .card {
            width: 100%;
            max-width: 430px;
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(217,139,170,.15);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .form-control {
            padding: 11px;
            border-radius: 10px;
        }
    </style>
</head>

<body>

<div class="card p-4">
    <div class="text-center mb-4">
        <h3 style="color:#D98BAA;">🌸 BoquetBaloon</h3>
        <p class="text-muted">Buat Akun Admin Pertama</p>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <form action="<?= site_url('setup/create') ?>" method="post">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Nama Lengkap</label>
            <input type="text" name="nama_lengkap"
                   class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username"
                   class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password"
                   class="form-control" minlength="8" required>
        </div>

        <div class="mb-4">
            <label class="form-label">Konfirmasi Password</label>
            <input type="password" name="konfirmasi_password"
                   class="form-control" minlength="8" required>
        </div>

        <button type="submit" class="btn btn-pink w-100">
            Buat Akun Admin
        </button>
    </form>
</div>

</body>
</html>