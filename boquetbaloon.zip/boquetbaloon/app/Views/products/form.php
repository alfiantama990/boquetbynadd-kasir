<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Form Produk - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            font-family: Arial, sans-serif;
            color: #39323A;
        }

        .form-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 750px;
            margin: 35px auto;
            box-shadow: 0 5px 25px rgba(217,139,170,.10);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 11px 20px;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .form-control, .form-select {
            padding: 11px;
            border-radius: 10px;
        }

        .preview-img {
            width: 130px;
            height: 130px;
            object-fit: cover;
            border-radius: 15px;
            margin-top: 10px;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="form-card">

        <div class="mb-4">
            <h3 style="color:#D98BAA;">
                🌸 <?= $product ? 'Edit Produk' : 'Tambah Produk' ?>
            </h3>

            <p class="text-muted">
                Lengkapi informasi produk bouquet kamu.
            </p>
        </div>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger">
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>

        <?php
            $isEdit = !empty($product);
            $action = $isEdit
                ? site_url('products/update/' . $product['id'])
                : site_url('products/store');
        ?>

        <form action="<?= $action ?>" method="post" enctype="multipart/form-data">

            <?= csrf_field() ?>

            <div class="mb-3">

                <label class="form-label fw-semibold">Nama Produk</label>

                <input type="text"
                       name="nama_produk"
                       class="form-control"
                       placeholder="Contoh: Bouquet Balon Pink"
                       value="<?= esc(old('nama_produk', $product['nama_produk'] ?? '')) ?>"
                       maxlength="150"
                       required>

            </div>

            <div class="mb-3">

                <label class="form-label fw-semibold">Kategori</label>

                <select name="category_id" class="form-select">

                    <option value="">Pilih Kategori</option>

                    <?php foreach ($categories as $category): ?>

                        <option value="<?= $category['id'] ?>"
                            <?= old('category_id', $product['category_id'] ?? '') == $category['id'] ? 'selected' : '' ?>>

                            <?= esc($category['nama_kategori']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="mb-3">

                <label class="form-label fw-semibold">Harga Jual (Rp)</label>

                <input type="number"
                       name="harga"
                       class="form-control"
                       placeholder="Contoh: 150000"
                       min="0"
                       step="1"
                       value="<?= esc(old('harga', $product['harga'] ?? '')) ?>"
                       required>

            </div>

            <div class="mb-3">

                <label class="form-label fw-semibold">Deskripsi Produk</label>

                <textarea name="deskripsi"
                          class="form-control"
                          rows="4"
                          placeholder="Deskripsikan produk kamu..."><?= esc(old('deskripsi', $product['deskripsi'] ?? '')) ?></textarea>

            </div>

            <div class="mb-4">

                <label class="form-label fw-semibold">Foto Produk</label>

                <input type="file"
                       name="foto"
                       class="form-control"
                       accept=".jpg,.jpeg,.png,.webp">

                <small class="text-muted">
                    Format JPG, PNG, WEBP. Maksimal 3 MB.
                </small>

                <?php if (!empty($product['foto'])): ?>

                    <div>
                        <p class="mt-3 mb-1">Foto saat ini:</p>

                        <img
                            src="<?= base_url('uploads/products/' . $product['foto']) ?>"
                            class="preview-img"
                            alt="Foto produk">
                    </div>

                <?php endif; ?>

            </div>

            <div class="d-flex gap-2">

                <button type="submit" class="btn btn-pink">
                    <i class="bi bi-save"></i>
                    <?= $isEdit ? 'Simpan Perubahan' : 'Simpan Produk' ?>
                </button>

                <a href="<?= site_url('products') ?>"
                   class="btn btn-outline-secondary">
                    Kembali
                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>