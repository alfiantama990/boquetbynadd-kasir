<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: Arial, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 35px;
            border-radius: 22px;
            box-shadow: 0 8px 30px rgba(217,139,170,.15);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 10px;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .form-control {
            padding: 12px;
            border-radius: 10px;
        }
    </style>
</head>

<body>

<div class="login-card">

    <div class="text-center mb-4">
        <h2 style="color:#D98BAA;">🌸 BoquetBaloon</h2>
        <p class="text-muted">Point of Sale System</p>
        <h5>Selamat Datang!</h5>
        <small class="text-muted">Silakan login untuk melanjutkan</small>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success">
            <?= esc(session()->getFlashdata('success')) ?>
        </div>
    <?php endif; ?>

    <form action="<?= site_url('login/process') ?>" method="post">

        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username"
                   class="form-control" required>
        </div>

        <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" name="password"
                   class="form-control" required>
        </div>

        <button type="submit" class="btn btn-pink w-100">
            Login
        </button>

    </form>

    <p class="text-center text-muted mt-4 mb-0">
        BoquetBaloon POS © 2026
    </p>

</div>

</body>
</html>