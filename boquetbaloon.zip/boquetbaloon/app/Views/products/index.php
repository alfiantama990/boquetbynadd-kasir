<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Manajemen Produk - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            font-family: Arial, sans-serif;
            color: #39323A;
        }

        .navbar {
            background: white;
            padding: 18px 25px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .brand {
            color: #D98BAA;
            font-weight: bold;
            font-size: 21px;
        }

        .main {
            padding: 30px;
        }

        .content-card {
            background: white;
            padding: 25px;
            border-radius: 18px;
            box-shadow: 0 5px 20px rgba(217,139,170,.08);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 10px 18px;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .product-img {
            width: 65px;
            height: 65px;
            object-fit: cover;
            border-radius: 12px;
        }

        .table th {
            background: #FFF0F5;
            color: #8D4966;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
        }

        .badge-category {
            background: #FCE5ED;
            color: #8D4966;
        }

        @media(max-width:768px) {
            .main {
                padding: 15px;
            }

            .content-card {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container-fluid">
        <div>
            <div class="brand">🌸 BoquetBaloon</div>
            <small class="text-muted">Point of Sale System</small>
        </div>

        <div>
            <a href="<?= site_url('dashboard') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>
</nav>

<div class="main">

    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">

        <div>
            <h3 class="fw-bold mb-1">Manajemen Produk</h3>
            <p class="text-muted mb-0">Kelola produk bouquet dan gift kamu.</p>
        </div>

        <a href="<?= site_url('products/create') ?>" class="btn btn-pink">
            <i class="bi bi-plus-circle"></i> Tambah Produk
        </a>

    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success">
            <?= esc(session()->getFlashdata('success')) ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <div class="content-card">

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!empty($products)): ?>

                        <?php $no = 1; ?>

                        <?php foreach ($products as $p): ?>

                            <tr>
                                <td><?= $no++ ?></td>

                                <td>
                                    <?php if ($p['foto']): ?>
                                        <img
                                            src="<?= base_url('uploads/products/' . $p['foto']) ?>"
                                            class="product-img"
                                            alt="Foto produk">
                                    <?php else: ?>
                                        <div class="product-img d-flex align-items-center justify-content-center"
                                             style="background:#FCE5ED;color:#D98BAA;">
                                            <i class="bi bi-image fs-3"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong><?= esc($p['nama_produk']) ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?= esc($p['deskripsi'] ?? '') ?>
                                    </small>
                                </td>

                                <td>
                                    <span class="badge badge-category">
                                        <?= esc($p['nama_kategori'] ?? 'Tanpa Kategori') ?>
                                    </span>
                                </td>

                                <td>
                                    <strong>
                                        Rp <?= number_format($p['harga'], 0, ',', '.') ?>
                                    </strong>
                                </td>

                                <td>
                                    <?php if ($p['is_active']): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="d-flex gap-2">

                                        <a href="<?= site_url('products/edit/' . $p['id']) ?>"
                                           class="btn btn-warning btn-sm">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <form action="<?= site_url('products/delete/' . $p['id']) ?>"
                                              method="post"
                                              onsubmit="return confirm('Yakin ingin menghapus produk ini?')">

                                            <?= csrf_field() ?>

                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="bi bi-trash"></i>
                                            </button>

                                        </form>

                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <i class="bi bi-box-seam fs-1 text-muted"></i>
                                <p class="text-muted mt-2 mb-0">
                                    Belum ada produk.
                                </p>
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    <div class="text-center text-muted mt-4">
        <small>BoquetBaloon POS © 2026</small>
    </div>

</div>

</body>
</html>