<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Riwayat Transaksi - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
        }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .pink {
            background: #F8C8DC;
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .table thead th {
            background: #FCE6EF;
            white-space: nowrap;
        }
    </style>
</head>

<body>

<div class="container-fluid p-3 p-md-4">

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h3 class="fw-bold mb-1">Riwayat Transaksi 🌸</h3>
            <p class="text-muted mb-0">Daftar seluruh transaksi penjualan.</p>
        </div>

        <a href="<?= site_url('dashboard') ?>" class="btn btn-light">
            Kembali ke Dashboard
        </a>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">

        <div class="col-md-6">
            <div class="card p-4">
                <div class="text-muted">Jumlah Transaksi</div>
                <h3 class="fw-bold mb-0">
                    <?= number_format($ringkasan['jumlah_transaksi'] ?? 0, 0, ',', '.') ?>
                </h3>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card p-4">
                <div class="text-muted">Total Omzet</div>
                <h3 class="fw-bold mb-0 text-success">
                    Rp <?= number_format($ringkasan['total_omzet'] ?? 0, 0, ',', '.') ?>
                </h3>
            </div>
        </div>

    </div>

    <div class="card p-3 p-md-4 mb-4">

        <h5 class="fw-bold mb-3">Filter Transaksi</h5>

        <form method="get" action="<?= site_url('sales') ?>">

            <div class="row g-3">

                <div class="col-md-3">
                    <label class="form-label">Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai"
                           class="form-control"
                           value="<?= esc($tanggalMulai ?? '') ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Tanggal Akhir</label>
                    <input type="date" name="tanggal_akhir"
                           class="form-control"
                           value="<?= esc($tanggalAkhir ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label">Cari Transaksi</label>
                    <input type="text" name="keyword"
                           class="form-control"
                           placeholder="Nomor invoice / nama pelanggan"
                           value="<?= esc($keyword ?? '') ?>">
                </div>

                <div class="col-md-2 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-pink w-100">
                        Cari
                    </button>
                </div>

            </div>

        </form>

    </div>

    <div class="card p-3 p-md-4">

        <h5 class="fw-bold mb-3">Daftar Penjualan</h5>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Invoice</th>
                        <th>Tanggal</th>
                        <th>Pelanggan</th>
                        <th>Kasir</th>
                        <th>Total</th>
                        <th>Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!empty($transaksi)): ?>

                        <?php foreach ($transaksi as $i => $t): ?>

                            <tr>
                                <td><?= $i + 1 ?></td>

                                <td class="fw-semibold">
                                    <?= esc($t['invoice_no']) ?>
                                </td>

                                <td>
                                    <?= date('d/m/Y H:i', strtotime($t['created_at'])) ?>
                                </td>

                                <td>
                                    <?= esc($t['customer_name'] ?: 'Umum') ?>
                                </td>

                                <td>
                                    <?= esc($t['nama_lengkap']) ?>
                                </td>

                                <td class="fw-bold">
                                    Rp <?= number_format($t['grand_total'], 0, ',', '.') ?>
                                </td>

                                <td>
                                    <span class="badge bg-secondary">
                                        <?= strtoupper(esc($t['payment_method'])) ?>
                                    </span>
                                </td>

                                <td>
                                    <a href="<?= site_url('sales/detail/' . $t['id']) ?>"
                                       class="btn btn-sm btn-pink">
                                        Detail
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Belum ada transaksi ditemukan.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>