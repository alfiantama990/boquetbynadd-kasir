<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Manajemen Pengguna - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
        }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .table thead th {
            background: #FCE6EF;
            white-space: nowrap;
        }
    </style>
</head>

<body>

<div class="container-fluid p-3 p-md-4">

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

        <div>
            <h3 class="fw-bold mb-1">Manajemen Pengguna 🌸</h3>
            <p class="text-muted mb-0">Kelola akun Admin dan Kasir.</p>
        </div>

        <div class="d-flex gap-2">
            <a href="<?= site_url('dashboard') ?>" class="btn btn-light">
                Dashboard
            </a>

            <a href="<?= site_url('users/create') ?>" class="btn btn-pink">
                + Tambah Pengguna
            </a>
        </div>

    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success">
            <?= esc(session()->getFlashdata('success')) ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <div class="card p-3 p-md-4">

        <h5 class="fw-bold mb-3">Daftar Pengguna</h5>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!empty($users)): ?>

                        <?php foreach ($users as $i => $u): ?>

                            <tr>
                                <td><?= $i + 1 ?></td>

                                <td class="fw-semibold">
                                    <?= esc($u['nama_lengkap']) ?>
                                </td>

                                <td>
                                    <?= esc($u['username']) ?>
                                </td>

                                <td>
                                    <?php if ($u['role'] === 'admin'): ?>
                                        <span class="badge bg-primary">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-info text-dark">Kasir</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if ($u['is_active']): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Nonaktif</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="d-flex gap-2">

                                        <a href="<?= site_url('users/edit/' . $u['id']) ?>"
                                           class="btn btn-sm btn-warning">
                                            Edit
                                        </a>

                                        <?php if ($u['is_active']): ?>

                                            <?php if ((int) $u['id'] !== (int) session()->get('user_id')): ?>

                                                <form method="post"
                                                      action="<?= site_url('users/delete/' . $u['id']) ?>"
                                                      onsubmit="return confirm('Yakin ingin menonaktifkan akun ini?')">

                                                    <?= csrf_field() ?>

                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        Nonaktifkan
                                                    </button>

                                                </form>

                                            <?php endif; ?>

                                        <?php endif; ?>

                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="6" class="text-center py-4">
                                Belum ada pengguna.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>