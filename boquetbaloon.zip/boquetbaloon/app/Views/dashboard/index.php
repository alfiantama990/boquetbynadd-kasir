<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dashboard - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
        }

        .sidebar {
            min-height: 100vh;
            background: #F8C8DC;
            padding: 25px 15px;
        }

        .sidebar a {
            display: block;
            padding: 12px 15px;
            color: #39323A;
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .sidebar a:hover {
            background: white;
        }

        .brand {
            font-size: 21px;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .stat-card {
            border: none;
            border-radius: 18px;
            padding: 22px;
            height: 100%;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .stat-icon {
            font-size: 28px;
            margin-bottom: 12px;
        }

        .pink-card {
            background: #F8C8DC;
        }

        .white-card {
            background: white;
        }

        .content {
            padding: 30px;
        }

        .panel {
            background: white;
            border-radius: 18px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        @media(max-width: 767px) {
            .sidebar {
                min-height: auto;
            }

            .content {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-md-3 col-lg-2 sidebar">

            <div class="brand">
                🌸 BoquetBaloon
                <div class="small fw-normal">Point of Sale</div>
            </div>

            <a href="<?= site_url('dashboard') ?>">🏠 Dashboard</a>

            <a href="<?= site_url('products') ?>">🎁 Produk</a>

            <a href="<?= site_url('cashier') ?>">🛒 Kasir</a>

            <a href="<?= site_url('sales') ?>">📋 Riwayat Transaksi</a>

            <?php if (session()->get('role') === 'admin'): ?>
                <a href="<?= site_url('users') ?>">👥 Manajemen Pengguna</a>
            <?php endif; ?>

            <hr>

            <a href="<?= site_url('logout') ?>">🚪 Logout</a>

        </div>

        <!-- CONTENT -->
        <div class="col-md-9 col-lg-10 content">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">

                <div>
                    <h3 class="fw-bold mb-1">Dashboard 🌷</h3>

                    <p class="text-muted mb-0">
                        Selamat datang,
                        <?= esc(session()->get('nama_lengkap')) ?>!
                    </p>
                </div>

                <div class="text-muted">
                    <?= date('d F Y') ?>
                </div>

            </div>

            <!-- STATISTIK -->
            <div class="row g-3 mb-4">

                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="stat-card pink-card">
                        <div class="stat-icon">💰</div>
                        <div>Omzet Hari Ini</div>

                        <h4 class="fw-bold mt-2">
                            Rp <?= number_format($omzetHariIni, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="stat-card white-card">
                        <div class="stat-icon">🧾</div>
                        <div>Transaksi Hari Ini</div>

                        <h4 class="fw-bold mt-2">
                            <?= number_format($transaksiHariIni, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="stat-card white-card">
                        <div class="stat-icon">🎁</div>
                        <div>Produk Aktif</div>

                        <h4 class="fw-bold mt-2">
                            <?= number_format($produkAktif, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="stat-card white-card">
                        <div class="stat-icon">👥</div>
                        <div>Pelanggan</div>

                        <h4 class="fw-bold mt-2">
                            <?= number_format($jumlahPelanggan, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>

            </div>

            <!-- GRAFIK -->
            <div class="panel mb-4">

                <h5 class="fw-bold mb-4">
                    Grafik Penjualan 7 Hari Terakhir
                </h5>

                <div style="height:300px;">
                    <canvas id="salesChart"></canvas>
                </div>

            </div>

            <!-- PRODUK TERLARIS -->
            <div class="panel">

                <h5 class="fw-bold mb-3">
                    ⭐ Produk Terlaris
                </h5>

                <div class="table-responsive">

                    <table class="table align-middle">

                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>Total Terjual</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php if (!empty($produkTerlaris)): ?>

                                <?php foreach ($produkTerlaris as $i => $produk): ?>

                                    <tr>
                                        <td><?= $i + 1 ?></td>

                                        <td class="fw-semibold">
                                            <?= esc($produk['product_name']) ?>
                                        </td>

                                        <td>
                                            <?= number_format($produk['total_terjual'], 0, ',', '.') ?>
                                            pcs
                                        </td>
                                    </tr>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <tr>
                                    <td colspan="3" class="text-center text-muted py-4">
                                        Belum ada data penjualan.
                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

            <div class="text-center text-muted mt-4">
                <small>© <?= date('Y') ?> BoquetBaloon POS</small>
            </div>

        </div>

    </div>
</div>

<script>
    const labels = <?= json_encode($grafikLabels) ?>;
    const values = <?= json_encode($grafikData) ?>;

    const ctx = document.getElementById('salesChart');

    new Chart(ctx, {
        type: 'line',

        data: {
            labels: labels,

            datasets: [{
                label: 'Omzet Penjualan',

                data: values,

                borderColor: '#D98BAA',

                backgroundColor: 'rgba(248, 200, 220, 0.35)',

                fill: true,

                tension: 0.4,

                borderWidth: 3,

                pointRadius: 5
            }]
        },

        options: {
            responsive: true,

            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: false
                }
            },

            scales: {
                y: {
                    beginAtZero: true,

                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
                        }
                    }
                }
            }
        }
    });
</script>

</body>
</html>