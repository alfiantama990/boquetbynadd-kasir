<?php

namespace App\Controllers;

class Sales extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('login'));
        }

        $db = \Config\Database::connect();

        $tanggalMulai = $this->request->getGet('tanggal_mulai');
        $tanggalAkhir = $this->request->getGet('tanggal_akhir');
        $keyword = trim($this->request->getGet('keyword') ?? '');

        $builder = $db->table('sales')
            ->select('sales.*, users.nama_lengkap')
            ->join('users', 'users.id = sales.user_id');

        if ($tanggalMulai) {
            $builder->where('DATE(sales.created_at) >=', $tanggalMulai);
        }

        if ($tanggalAkhir) {
            $builder->where('DATE(sales.created_at) <=', $tanggalAkhir);
        }

        if ($keyword !== '') {
            $builder->groupStart()
                ->like('sales.invoice_no', $keyword)
                ->orLike('sales.customer_name', $keyword)
                ->groupEnd();
        }

        $transaksi = $builder
            ->orderBy('sales.id', 'DESC')
            ->get()
            ->getResultArray();

        $summary = $db->table('sales')
            ->select('COUNT(*) as jumlah_transaksi, COALESCE(SUM(grand_total), 0) as total_omzet');

        if ($tanggalMulai) {
            $summary->where('DATE(created_at) >=', $tanggalMulai);
        }

        if ($tanggalAkhir) {
            $summary->where('DATE(created_at) <=', $tanggalAkhir);
        }

        $ringkasan = $summary->get()->getRowArray();

        return view('sales/index', [
            'transaksi' => $transaksi,
            'ringkasan' => $ringkasan,
            'tanggalMulai' => $tanggalMulai,
            'tanggalAkhir' => $tanggalAkhir,
            'keyword' => $keyword
        ]);
    }

    public function detail($id)
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('login'));
        }

        $db = \Config\Database::connect();

        $transaksi = $db->table('sales')
            ->select('sales.*, users.nama_lengkap')
            ->join('users', 'users.id = sales.user_id')
            ->where('sales.id', $id)
            ->get()
            ->getRowArray();

        if (!$transaksi) {
            return redirect()->to(site_url('sales'))
                ->with('error', 'Transaksi tidak ditemukan.');
        }

        $items = $db->table('sale_items')
            ->where('sale_id', $id)
            ->get()
            ->getResultArray();

        return view('sales/detail', [
            'transaksi' => $transaksi,
            'items' => $items
        ]);
    }
}