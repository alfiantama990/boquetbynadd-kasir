<!-- Shared Web Bluetooth Thermal Printer Scanner (58mm) -->
<div class="modal fade" id="bpScannerModal" tabindex="-1" aria-hidden="true" style="display:none;">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="border-radius:18px;border:none;box-shadow:0 20px 50px rgba(0,0,0,.22);">
            <div class="modal-header" style="border-bottom:1px solid #f3e5eb;">
                <div>
                    <h5 class="modal-title fw-bold">Scanner Printer Bluetooth (58mm)</h5>
                    <small class="text-muted">Direct print struk thermal langsung dari browser (ESC/POS).</small>
                </div>
                <button type="button" class="btn-close" id="bpBtnCloseModal" aria-label="Tutup"></button>
            </div>

            <div class="modal-body">
                <!-- Status Koneksi -->
                <div class="p-3 rounded-3 mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2"
                     style="background:#FFF8F5;border:1px solid #f4e2e9;">
                    <div>
                        <span class="badge bg-danger mb-1" id="bpStatusBadge">Terputus</span>
                        <h6 class="mb-0 fw-bold" id="bpDeviceName">Belum ada printer tersambung</h6>
                        <small class="text-muted" id="bpDeviceMeta">
                            Klik Scan Cepat atau tombol Scan di bawah untuk memilih printer Bluetooth.
                        </small>
                    </div>
                    <button type="button" class="btn btn-outline-danger btn-sm d-none" id="bpBtnDisconnect">
                        Putuskan
                    </button>
                </div>

                <!-- Pilihan Scan -->
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <button type="button" id="bpBtnScanAll"
                                class="btn w-100 text-start p-3 h-100"
                                style="background:#FCE5ED;border:1px solid #D98BAA;border-radius:12px;">
                            <strong class="d-block text-dark">⚡ Scan Cepat (Semua Perangkat)</strong>
                            <small class="text-muted">Direkomendasikan — memunculkan RPP02, EPPOS, Xprinter, Zjiang, dll.</small>
                        </button>
                    </div>
                    <div class="col-md-6">
                        <button type="button" id="bpBtnScanThermal"
                                class="btn btn-light w-100 text-start p-3 h-100 border"
                                style="border-radius:12px;">
                            <strong class="d-block text-dark">🔍 Scan Filter Printer Thermal</strong>
                            <small class="text-muted">Menyaring berdasarkan UUID &amp; prefix nama printer thermal.</small>
                        </button>
                    </div>
                    <div class="col-md-6">
                        <button type="button" id="bpBtnReconnect"
                                class="btn btn-light w-100 text-start p-3 h-100 border"
                                style="border-radius:12px;">
                            <strong class="d-block text-dark">🔄 Auto-Reconnect Terakhir</strong>
                            <small class="text-muted">Menghubungkan ulang printer yang sudah pernah dipasangkan.</small>
                        </button>
                    </div>
                    <div class="col-md-6">
                        <button type="button" id="bpBtnConnectSerial"
                                class="btn btn-light w-100 text-start p-3 h-100 border"
                                style="border-radius:12px;">
                            <strong class="d-block text-dark">🔌 USB / Serial COM Port</strong>
                            <small class="text-muted">Alternatif kabel USB atau Bluetooth Classic SPP COM Port.</small>
                        </button>
                    </div>
                </div>

                <!-- Pengaturan Struk 58mm -->
                <div class="card border mb-3" style="border-radius:12px;">
                    <div class="card-body">
                        <h6 class="fw-bold mb-3">Pengaturan Printer &amp; Struk</h6>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <label class="form-label small text-muted mb-1">Nama Toko (Header Struk)</label>
                                <input type="text" class="form-control form-control-sm" id="bpStoreName" value="BoquetBaloon">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small text-muted mb-1">Alamat / Catatan Header (Opsional)</label>
                                <input type="text" class="form-control form-control-sm" id="bpStoreAddress" placeholder="Contoh: Jl. Mawar No. 10">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small text-muted mb-1">Ukuran Kertas Printer</label>
                                <select class="form-select form-select-sm" id="bpPaperWidth">
                                    <option value="58" selected>58mm (32 karakter) - Default</option>
                                    <option value="80">80mm (48 karakter)</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small text-muted mb-1">BLE Chunk Size</label>
                                <select class="form-select form-select-sm" id="bpChunkSize">
                                    <option value="20">20 byte (Paling aman)</option>
                                    <option value="64">64 byte (Seimbang)</option>
                                    <option value="100" selected>100 byte (Cepat)</option>
                                </select>
                            </div>
                        </div>
                        <div class="d-flex gap-2 mt-3 flex-wrap">
                            <button type="button" id="bpBtnTestPrint" class="btn btn-sm text-white" style="background:#D98BAA;">
                                🖨️ Test Print 58mm
                            </button>
                            <button type="button" id="bpBtnFeedPaper" class="btn btn-sm btn-outline-secondary">
                                Feed Kertas
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Log GATT & Scanner -->
                <div class="card border" style="border-radius:12px;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                            <h6 class="fw-bold mb-0">Log Scanner &amp; GATT</h6>
                            <div class="d-flex align-items-center gap-2">
                                <small class="text-muted" id="bpUuidInfo">Service: - | Char: -</small>
                                <button type="button" id="bpBtnClearLog" class="btn btn-link btn-sm p-0">Bersihkan</button>
                            </div>
                        </div>
                        <pre id="bpScannerLog"
                             class="mb-0 p-2 rounded-2"
                             style="background:#0f172a;color:#e2e8f0;font-size:12px;height:130px;overflow-y:auto;white-space:pre-wrap;"></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="bpModalBackdrop" class="modal-backdrop fade show d-none" style="z-index:1040;"></div>
<div id="bpToastContainer"
     style="position:fixed;right:20px;bottom:20px;display:flex;flex-direction:column;gap:8px;z-index:1090;"></div>

<script type="module">
    import { initBoquetPrinter } from '<?= base_url('assets/js/boquet-printer-ui.js') ?>';

    initBoquetPrinter({
        autoReconnectOnLoad: <?= !empty($autoReconnectPrinter) ? 'true' : 'false' ?>
    });
</script>
