import { EscPosBuilder } from './escpos.js';
import { BluetoothPrinterScanner } from './printer-scanner.js';

const SETTINGS_KEY = 'boquetbaloon_printer_settings';

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return {
      paperWidth: parsed.paperWidth === 80 ? 80 : 58,
      chunkSize: [20, 64, 100].includes(Number(parsed.chunkSize)) ? Number(parsed.chunkSize) : 100,
      storeName: parsed.storeName || 'BoquetBaloon',
      storeSubtitle: parsed.storeSubtitle || 'Bukti Transaksi Penjualan',
      storeAddress: parsed.storeAddress || '',
      storePhone: parsed.storePhone || '',
    };
  } catch {
    return {
      paperWidth: 58,
      chunkSize: 100,
      storeName: 'BoquetBaloon',
      storeSubtitle: 'Bukti Transaksi Penjualan',
      storeAddress: '',
      storePhone: '',
    };
  }
}

function saveSettings(settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage failures
  }
}

export function initBoquetPrinter(options = {}) {
  const settings = loadSettings();

  const els = {
    modal: document.getElementById('bpScannerModal'),
    backdrop: document.getElementById('bpModalBackdrop'),
    btnClose: document.getElementById('bpBtnCloseModal'),
    statusBadge: document.getElementById('bpStatusBadge'),
    deviceName: document.getElementById('bpDeviceName'),
    deviceMeta: document.getElementById('bpDeviceMeta'),
    uuidInfo: document.getElementById('bpUuidInfo'),
    btnDisconnect: document.getElementById('bpBtnDisconnect'),
    btnScanAll: document.getElementById('bpBtnScanAll'),
    btnScanThermal: document.getElementById('bpBtnScanThermal'),
    btnReconnect: document.getElementById('bpBtnReconnect'),
    btnConnectSerial: document.getElementById('bpBtnConnectSerial'),
    paperWidthSelect: document.getElementById('bpPaperWidth'),
    chunkSizeSelect: document.getElementById('bpChunkSize'),
    storeNameInput: document.getElementById('bpStoreName'),
    storeAddressInput: document.getElementById('bpStoreAddress'),
    btnTestPrint: document.getElementById('bpBtnTestPrint'),
    btnFeedPaper: document.getElementById('bpBtnFeedPaper'),
    logBox: document.getElementById('bpScannerLog'),
    btnClearLog: document.getElementById('bpBtnClearLog'),
    toastContainer: document.getElementById('bpToastContainer'),
  };

  if (els.paperWidthSelect) els.paperWidthSelect.value = String(settings.paperWidth);
  if (els.chunkSizeSelect) els.chunkSizeSelect.value = String(settings.chunkSize);
  if (els.storeNameInput) els.storeNameInput.value = settings.storeName;
  if (els.storeAddressInput) els.storeAddressInput.value = settings.storeAddress;

  function showToast(message, type = 'info') {
    if (!els.toastContainer) return;
    const bgMap = {
      success: '#198754',
      error: '#dc3545',
      warn: '#d97706',
      info: '#212529',
    };
    const toast = document.createElement('div');
    toast.style.cssText = `
      background: ${bgMap[type] || bgMap.info};
      color: #fff;
      padding: 11px 16px;
      border-radius: 10px;
      font-size: 0.88rem;
      font-weight: 500;
      box-shadow: 0 8px 24px rgba(0,0,0,0.18);
      max-width: 360px;
    `;
    toast.textContent = message;
    els.toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 3600);
  }

  function appendLog({ time, level, message }) {
    if (!els.logBox) return;
    const prefix = level === 'error' ? '[ERR]' : level === 'warn' ? '[WARN]' : level === 'success' ? '[OK]' : '[INFO]';
    els.logBox.textContent += `${time} ${prefix} ${message}\n`;
    els.logBox.scrollTop = els.logBox.scrollHeight;
  }

  function updateStatusUI(info) {
    // Update all navbar status buttons on the page
    document.querySelectorAll('[data-bp-status-btn]').forEach((btn) => {
      const label = btn.querySelector('[data-bp-status-label]');
      const dot = btn.querySelector('[data-bp-status-dot]');
      if (info.connected) {
        btn.classList.remove('btn-outline-secondary');
        btn.classList.add('btn-success');
        if (label) label.textContent = info.name;
        if (dot) dot.style.background = '#bbf7d0';
      } else {
        btn.classList.remove('btn-success');
        btn.classList.add('btn-outline-secondary');
        if (label) label.textContent = 'Hubungkan Printer';
        if (dot) dot.style.background = '#ef4444';
      }
    });

    if (els.statusBadge) {
      if (info.connected) {
        els.statusBadge.className = 'badge bg-success';
        els.statusBadge.textContent = `Tersambung (${info.transport})`;
      } else {
        els.statusBadge.className = 'badge bg-danger';
        els.statusBadge.textContent = 'Terputus';
      }
    }

    if (els.deviceName) {
      els.deviceName.textContent = info.connected ? info.name : 'Belum ada printer tersambung';
    }
    if (els.deviceMeta) {
      els.deviceMeta.textContent = info.connected
        ? `Mode kirim: ${info.writeMode} • Kertas: ${getCurrentSettings().paperWidth}mm`
        : 'Klik Scan Cepat atau tombol Scan di bawah untuk memilih printer Bluetooth.';
    }
    if (els.uuidInfo) {
      els.uuidInfo.textContent = `Service: ${info.serviceUuid} | Char: ${info.characteristicUuid}`;
    }
    if (els.btnDisconnect) {
      els.btnDisconnect.classList.toggle('d-none', !info.connected);
    }

    window.dispatchEvent(new CustomEvent('boquetprinter:status', { detail: info }));
  }

  function getCurrentSettings() {
    const next = {
      paperWidth: Number(els.paperWidthSelect?.value) === 80 ? 80 : 58,
      chunkSize: Number(els.chunkSizeSelect?.value) || 100,
      storeName: els.storeNameInput?.value.trim() || 'BoquetBaloon',
      storeSubtitle: 'Bukti Transaksi Penjualan',
      storeAddress: els.storeAddressInput?.value.trim() || '',
      storePhone: '',
    };
    saveSettings(next);
    return next;
  }

  const scanner = new BluetoothPrinterScanner({
    chunkSize: settings.chunkSize,
    chunkDelayMs: 20,
    onStatusChange: updateStatusUI,
    onLog: appendLog,
  });

  function openModal() {
    if (!els.modal) return;
    els.modal.style.display = 'block';
    els.modal.classList.add('show');
    els.modal.setAttribute('aria-hidden', 'false');
    if (els.backdrop) els.backdrop.classList.remove('d-none');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    if (!els.modal) return;
    els.modal.style.display = 'none';
    els.modal.classList.remove('show');
    els.modal.setAttribute('aria-hidden', 'true');
    if (els.backdrop) els.backdrop.classList.add('d-none');
    document.body.style.overflow = '';
  }

  async function scanAndConnect(mode = 'all') {
    try {
      const s = getCurrentSettings();
      scanner.chunkSize = s.chunkSize;
      const info = await scanner.scanAndConnect({ filterMode: mode });
      showToast(`Perangkat berhasil tersambung: ${info.name}`, 'success');
      return info;
    } catch (err) {
      if (err.name === 'NotFoundError') {
        scanner.log('Scan dibatalkan oleh pengguna.', 'warn');
        return null;
      }
      scanner.log(err.message, 'error');
      showToast(err.message, 'error');
      throw err;
    }
  }

  async function printSaleReceipt(saleData) {
    const s = getCurrentSettings();
    scanner.chunkSize = s.chunkSize;

    const payload = {
      storeName: saleData.storeName || s.storeName,
      subtitle: saleData.subtitle || s.storeSubtitle,
      address: saleData.address || s.storeAddress,
      orderId: saleData.orderId || saleData.invoice_no,
      date: saleData.date || saleData.created_at,
      customerName: saleData.customerName || saleData.customer_name || 'Umum',
      cashier: saleData.cashier || saleData.nama_lengkap || '',
      items: saleData.items || [],
      subtotal: saleData.subtotal ?? saleData.total,
      discount: saleData.discount ?? 0,
      total: saleData.total ?? saleData.grand_total,
      paymentMethod: saleData.paymentMethod || saleData.payment_method,
      paid: saleData.paid ?? saleData.paid_amount,
      change: saleData.change ?? saleData.change_amount,
      footer:
        saleData.footer ||
        'Terima kasih sudah berbelanja!\nBoquetBaloon POS',
      qrData: saleData.qrData || '',
    };

    const bytes = EscPosBuilder.buildReceipt(payload, s.paperWidth);
    await scanner.printRaw(bytes);
    showToast(`Struk ${s.paperWidth}mm berhasil dicetak!`, 'success');
    return bytes.length;
  }

  async function testPrint() {
    const s = getCurrentSettings();
    const bytes = EscPosBuilder.buildReceipt(
      {
        storeName: s.storeName,
        subtitle: 'Test Print Printer 58mm',
        address: s.storeAddress,
        orderId: 'TEST-58MM-001',
        date: new Date().toLocaleString('id-ID'),
        customerName: 'Umum',
        cashier: 'Tester',
        items: [
          { name: 'Buket Balon Pastel', qty: 1, price: 75000 },
          { name: 'Kartu Ucapan Custom', qty: 2, price: 5000 },
        ],
        subtotal: 85000,
        discount: 0,
        total: 85000,
        paymentMethod: 'CASH',
        paid: 100000,
        change: 15000,
        footer: 'Test Print 58mm Berhasil!\nBoquetBaloon POS',
      },
      s.paperWidth
    );

    scanner.chunkSize = s.chunkSize;
    await scanner.printRaw(bytes);
    showToast(`Test print ${s.paperWidth}mm berhasil!`, 'success');
  }

  // Wire up modal & navbar triggers
  document.querySelectorAll('[data-bp-open-modal]').forEach((el) => {
    el.addEventListener('click', openModal);
  });

  document.querySelectorAll('[data-bp-quick-scan]').forEach((el) => {
    el.addEventListener('click', () => {
      scanAndConnect('all').catch(() => {});
    });
  });

  if (els.btnClose) els.btnClose.addEventListener('click', closeModal);
  if (els.backdrop) els.backdrop.addEventListener('click', closeModal);
  if (els.modal) {
    els.modal.addEventListener('click', (e) => {
      if (e.target === els.modal) closeModal();
    });
  }

  if (els.btnScanAll) els.btnScanAll.addEventListener('click', () => scanAndConnect('all').catch(() => {}));
  if (els.btnScanThermal) els.btnScanThermal.addEventListener('click', () => scanAndConnect('thermal').catch(() => {}));

  if (els.btnReconnect) {
    els.btnReconnect.addEventListener('click', async () => {
      try {
        const info = await scanner.tryAutoReconnect();
        showToast(`Berhasil tersambung ulang: ${info.name}`, 'success');
      } catch (err) {
        scanner.log(err.message, 'error');
        showToast(err.message, 'error');
      }
    });
  }

  if (els.btnConnectSerial) {
    els.btnConnectSerial.addEventListener('click', async () => {
      try {
        const info = await scanner.connectSerial({ baudRate: 9600 });
        showToast(`Serial / USB tersambung: ${info.name}`, 'success');
      } catch (err) {
        if (err.name === 'NotFoundError') return;
        scanner.log(err.message, 'error');
        showToast(err.message, 'error');
      }
    });
  }

  if (els.btnDisconnect) {
    els.btnDisconnect.addEventListener('click', async () => {
      await scanner.disconnect();
      showToast('Koneksi printer diputus.', 'info');
    });
  }

  [els.paperWidthSelect, els.chunkSizeSelect, els.storeNameInput, els.storeAddressInput].forEach((input) => {
    if (input) {
      input.addEventListener('change', () => {
        const s = getCurrentSettings();
        scanner.chunkSize = s.chunkSize;
        updateStatusUI(scanner.deviceInfo);
      });
    }
  });

  if (els.btnTestPrint) {
    els.btnTestPrint.addEventListener('click', () => {
      testPrint().catch((err) => showToast(err.message, 'error'));
    });
  }

  if (els.btnFeedPaper) {
    els.btnFeedPaper.addEventListener('click', async () => {
      try {
        const bytes = new EscPosBuilder(getCurrentSettings().paperWidth).init().feed(4).build();
        await scanner.printRaw(bytes);
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  if (els.btnClearLog && els.logBox) {
    els.btnClearLog.addEventListener('click', () => {
      els.logBox.textContent = '';
    });
  }

  const support = BluetoothPrinterScanner.checkSupport();
  if (!support.isSecure || !support.hasBluetooth) {
    scanner.log(
      !support.isSecure
        ? 'Peringatan: Buka lewat http://localhost/ atau https:// agar Web Bluetooth aktif.'
        : 'Peringatan: Gunakan Chrome/Edge agar Web Bluetooth aktif.',
      'warn'
    );
  } else {
    scanner.log('Web Bluetooth siap (default kertas 58mm / 32 kolom).', 'success');
    if (options.autoReconnectOnLoad && support.canAutoReconnect && scanner.getSavedDeviceMeta()) {
      scanner.tryAutoReconnect().catch(() => {
        // Silent background attempt; user can click Scan Cepat / Reconnect manually
      });
    }
  }

  const api = {
    scanner,
    EscPosBuilder,
    isConnected: () => scanner.isConnected,
    getDeviceInfo: () => scanner.deviceInfo,
    getSettings: getCurrentSettings,
    scanAndConnect,
    tryAutoReconnect: () => scanner.tryAutoReconnect(),
    printSaleReceipt,
    testPrint,
    openModal,
    closeModal,
    showToast,
  };

  window.BoquetPrinter = api;
  window.dispatchEvent(new CustomEvent('boquetprinter:ready', { detail: api }));
  return api;
}
