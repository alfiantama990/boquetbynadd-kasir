<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Transaksi - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
            font-family: Arial, sans-serif;
        }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        /* Tampilan cetak thermal */
        @media print {

            @page {
                size: 58mm auto;
                margin: 2mm;
            }

            body {
                background: white;
                width: 54mm;
                margin: 0 auto;
                font-size: 10px;
                color: black;
            }

            .container {
                width: 54mm !important;
                max-width: 54mm !important;
                padding: 0 !important;
                margin: 0 auto !important;
            }

            .no-print {
                display: none !important;
            }

            .card {
                width: 100%;
                padding: 2mm !important;
                box-shadow: none;
                border: none;
            }

            h3 {
                font-size: 15px;
            }

            h5 {
                font-size: 12px;
            }

            p, small, span, strong, td, th {
                font-size: 9px !important;
            }

            table {
                width: 100% !important;
                border-collapse: collapse;
            }

            th, td {
                padding: 3px 1px !important;
            }

            hr {
                border-top: 1px dashed black;
                opacity: 1;
            }
        }
    </style>
</head>

<body>

<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4 no-print flex-wrap gap-2">
        <h3 class="fw-bold mb-0">Detail Transaksi 🌸</h3>

        <div class="d-flex gap-2 flex-wrap">
            <button type="button"
                    class="btn btn-outline-secondary d-inline-flex align-items-center gap-2"
                    data-bp-open-modal
                    data-bp-status-btn>
                <span data-bp-status-dot style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block;"></span>
                <span data-bp-status-label>Hubungkan Printer</span>
            </button>

            <button type="button"
                    class="btn btn-outline-primary"
                    data-bp-quick-scan>
                ⚡ Scan Cepat
            </button>

            <button type="button" id="btnDirectPrintDetail" class="btn btn-success">
                🖨️ Direct Print 58mm
            </button>

            <button onclick="window.print()" class="btn btn-pink no-print">
                Cetak Browser
            </button>

            <a href="<?= site_url('sales') ?>" class="btn btn-light">
                Kembali
            </a>
        </div>
    </div>

    <div class="card p-4">

        <div class="text-center mb-4">
            <h3 class="fw-bold">BoquetBaloon</h3>
            <p class="text-muted mb-0">Bukti Transaksi Penjualan</p>
        </div>

        <hr>

        <div class="row mb-4">

            <div class="col-6">
                <small class="text-muted">Nomor Invoice</small>
                <div class="fw-bold">
                    <?= esc($transaksi['invoice_no']) ?>
                </div>
            </div>

            <div class="col-6 text-end">
                <small class="text-muted">Tanggal</small>
                <div class="fw-bold">
                    <?= date('d/m/Y H:i', strtotime($transaksi['created_at'])) ?>
                </div>
            </div>

            <div class="col-6 mt-3">
                <small class="text-muted">Pelanggan</small>
                <div class="fw-bold">
                    <?= esc($transaksi['customer_name'] ?: 'Umum') ?>
                </div>
            </div>

            <div class="col-6 mt-3 text-end">
                <small class="text-muted">Kasir</small>
                <div class="fw-bold">
                    <?= esc($transaksi['nama_lengkap']) ?>
                </div>
            </div>

        </div>

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($items as $item): ?>

                        <tr>
                            <td><?= esc($item['product_name']) ?></td>

                            <td>
                                Rp <?= number_format($item['price'], 0, ',', '.') ?>
                            </td>

                            <td><?= number_format($item['quantity']) ?></td>

                            <td class="text-end">
                                Rp <?= number_format($item['subtotal'], 0, ',', '.') ?>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

        <hr>

        <div class="row justify-content-end">
            <div class="col-md-5">

                <div class="d-flex justify-content-between mb-2">
                    <span>Total</span>
                    <strong>
                        Rp <?= number_format($transaksi['total'], 0, ',', '.') ?>
                    </strong>
                </div>

                <div class="d-flex justify-content-between mb-2">
                    <span>Diskon</span>
                    <strong>
                        Rp <?= number_format($transaksi['discount'], 0, ',', '.') ?>
                    </strong>
                </div>

                <div class="d-flex justify-content-between mb-2 fs-5">
                    <strong>Total Bayar</strong>
                    <strong class="text-success">
                        Rp <?= number_format($transaksi['grand_total'], 0, ',', '.') ?>
                    </strong>
                </div>

                <div class="d-flex justify-content-between mb-2">
                    <span>Metode Pembayaran</span>
                    <strong>
                        <?= strtoupper(esc($transaksi['payment_method'])) ?>
                    </strong>
                </div>

                <div class="d-flex justify-content-between mb-2">
                    <span>Uang Diterima</span>
                    <strong>
                        Rp <?= number_format($transaksi['paid_amount'], 0, ',', '.') ?>
                    </strong>
                </div>

                <div class="d-flex justify-content-between">
                    <span>Kembalian</span>
                    <strong>
                        Rp <?= number_format($transaksi['change_amount'], 0, ',', '.') ?>
                    </strong>
                </div>

            </div>
        </div>

        <hr>

        <div class="text-center mt-3">
            <p class="mb-1 fw-semibold">Terima kasih sudah berbelanja 💗</p>
            <small class="text-muted">BoquetBaloon POS</small>
        </div>

    </div>

</div>

<?= view('partials/printer_scanner', ['autoReconnectPrinter' => true]) ?>

<script>
    const DETAIL_SALE_RECEIPT = {
        orderId: <?= json_encode($transaksi['invoice_no']) ?>,
        date: <?= json_encode(date('d/m/Y H:i', strtotime($transaksi['created_at']))) ?>,
        customerName: <?= json_encode($transaksi['customer_name'] ?: 'Umum') ?>,
        cashier: <?= json_encode($transaksi['nama_lengkap'] ?? '') ?>,
        items: <?= json_encode(array_map(static function ($item) {
            return [
                'name' => $item['product_name'],
                'qty' => (int) $item['quantity'],
                'price' => (float) $item['price'],
                'subtotal' => (float) $item['subtotal'],
            ];
        }, $items)) ?>,
        subtotal: <?= (float) $transaksi['total'] ?>,
        discount: <?= (float) $transaksi['discount'] ?>,
        total: <?= (float) $transaksi['grand_total'] ?>,
        paymentMethod: <?= json_encode($transaksi['payment_method']) ?>,
        paid: <?= (float) $transaksi['paid_amount'] ?>,
        change: <?= (float) $transaksi['change_amount'] ?>
    };

    document.getElementById('btnDirectPrintDetail').addEventListener('click', async function () {
        if (!window.BoquetPrinter) return;
        const btn = this;
        const originalText = btn.innerHTML;
        btn.disabled = true;

        try {
            if (!window.BoquetPrinter.isConnected()) {
                const info = await window.BoquetPrinter.scanAndConnect('all');
                if (!info) return;
            }
            btn.innerHTML = 'Mencetak 58mm...';
            await window.BoquetPrinter.printSaleReceipt(DETAIL_SALE_RECEIPT);
        } catch (err) {
            window.BoquetPrinter.showToast(err.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    });
</script>

</body>
</html>