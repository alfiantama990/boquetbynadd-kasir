<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Form Pengguna - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
        }

        .card {
            border: none;
            border-radius: 18px;
            box-shadow: 0 4px 15px rgba(0,0,0,.04);
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }
    </style>
</head>

<body>

<div class="container py-4">

    <?php $isEdit = !empty($user); ?>

    <div class="mb-4">
        <h3 class="fw-bold">
            <?= $isEdit ? 'Edit Pengguna' : 'Tambah Pengguna' ?> 🌸
        </h3>

        <p class="text-muted">
            Isi informasi akun pengguna.
        </p>
    </div>

    <div class="card p-4">

        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post"
              action="<?= $isEdit
                  ? site_url('users/update/' . $user['id'])
                  : site_url('users/store') ?>">

            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label fw-semibold">Nama Lengkap</label>

                <input type="text"
                       name="nama_lengkap"
                       class="form-control"
                       value="<?= esc(old('nama_lengkap', $user['nama_lengkap'] ?? '')) ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>

                <input type="text"
                       name="username"
                       class="form-control"
                       value="<?= esc(old('username', $user['username'] ?? '')) ?>"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">
                    Password
                </label>

                <input type="password"
                       name="password"
                       class="form-control"
                       <?= $isEdit ? '' : 'required' ?>>

                <?php if ($isEdit): ?>
                    <small class="text-muted">
                        Kosongkan jika tidak ingin mengganti password.
                    </small>
                <?php else: ?>
                    <small class="text-muted">
                        Minimal 6 karakter.
                    </small>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <label class="form-label fw-semibold">Role Pengguna</label>

                <select name="role" class="form-select" required>

                    <option value="kasir"
                        <?= old('role', $user['role'] ?? 'kasir') === 'kasir' ? 'selected' : '' ?>>
                        Kasir
                    </option>

                    <option value="admin"
                        <?= old('role', $user['role'] ?? '') === 'admin' ? 'selected' : '' ?>>
                        Admin
                    </option>

                </select>
            </div>

            <div class="d-flex gap-2">

                <button type="submit" class="btn btn-pink px-4">
                    Simpan
                </button>

                <a href="<?= site_url('users') ?>" class="btn btn-light px-4">
                    Kembali
                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>