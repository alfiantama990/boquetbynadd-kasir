<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Kasir - BoquetBaloon POS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: #FFF8F5;
            color: #39323A;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background: white;
            padding: 15px 25px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .brand {
            color: #D98BAA;
            font-weight: bold;
            font-size: 21px;
        }

        .main {
            padding: 25px;
        }

        .panel {
            background: white;
            border-radius: 18px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(217,139,170,.08);
        }

        .product-card {
            border: 1px solid #f4e2e9;
            border-radius: 15px;
            padding: 15px;
            height: 100%;
            cursor: pointer;
            transition: .2s;
        }

        .product-card:hover {
            border-color: #D98BAA;
            transform: translateY(-3px);
        }

        .product-image {
            width: 100%;
            height: 125px;
            object-fit: cover;
            border-radius: 12px;
            background: #FCE5ED;
        }

        .placeholder {
            height: 125px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #FCE5ED;
            color: #D98BAA;
            border-radius: 12px;
            font-size: 35px;
        }

        .btn-pink {
            background: #D98BAA;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 11px;
        }

        .btn-pink:hover {
            background: #c87999;
            color: white;
        }

        .cart-item {
            border-bottom: 1px solid #f3e5eb;
            padding: 12px 0;
        }

        .money {
            font-size: 21px;
            color: #D98BAA;
            font-weight: bold;
        }

        @media(max-width:768px) {
            .main {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <div class="brand">🌸 BoquetBaloon POS</div>
            <small class="text-muted">Halaman Kasir</small>
        </div>

        <div class="d-flex align-items-center gap-2 flex-wrap">
            <button type="button"
                    class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-2"
                    data-bp-open-modal
                    data-bp-status-btn
                    title="Pengaturan & Status Printer 58mm">
                <span data-bp-status-dot style="width:8px;height:8px;border-radius:50%;background:#ef4444;display:inline-block;"></span>
                <i class="bi bi-printer"></i>
                <span data-bp-status-label>Hubungkan Printer</span>
            </button>

            <button type="button"
                    class="btn btn-pink btn-sm d-inline-flex align-items-center gap-1"
                    style="padding:5px 12px;"
                    data-bp-quick-scan
                    title="Scan Cepat Printer Bluetooth">
                <i class="bi bi-bluetooth"></i> Scan Cepat
            </button>

            <a href="<?= site_url('dashboard') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>
</nav>

<div class="main">

    <div class="row g-3">

        <!-- DAFTAR PRODUK -->
        <div class="col-lg-7">

            <div class="panel">

                <h5 class="mb-3">Pilih Produk 🌷</h5>

                <input type="text"
                       id="searchProduct"
                       class="form-control mb-3"
                       placeholder="Cari nama produk...">

                <div class="row g-3" id="productList">

                    <?php foreach ($products as $p): ?>

                        <div class="col-6 col-md-4 product-wrapper"
                             data-name="<?= esc(strtolower($p['nama_produk'])) ?>">

                            <div class="product-card"
                                 onclick="addToCart(
                                    <?= (int)$p['id'] ?>,
                                    '<?= esc($p['nama_produk'], 'js') ?>',
                                    <?= (float)$p['harga'] ?>
                                 )">

                                <?php if ($p['foto']): ?>

                                    <img src="<?= base_url('uploads/products/' . $p['foto']) ?>"
                                         class="product-image"
                                         alt="<?= esc($p['nama_produk']) ?>">

                                <?php else: ?>

                                    <div class="placeholder">
                                        <i class="bi bi-image"></i>
                                    </div>

                                <?php endif; ?>

                                <h6 class="mt-2 mb-1">
                                    <?= esc($p['nama_produk']) ?>
                                </h6>

                                <strong style="color:#D98BAA;">
                                    Rp <?= number_format($p['harga'], 0, ',', '.') ?>
                                </strong>

                                <button class="btn btn-pink w-100 mt-2 btn-sm">
                                    <i class="bi bi-plus"></i> Tambah
                                </button>

                            </div>
                        </div>

                    <?php endforeach; ?>

                    <?php if (empty($products)): ?>
                        <div class="col-12 text-center text-muted py-5">
                            Belum ada produk aktif.
                            <br>
                            Silakan tambahkan produk terlebih dahulu.
                        </div>
                    <?php endif; ?>

                </div>

            </div>

        </div>

        <!-- KERANJANG -->
        <div class="col-lg-5">

            <div class="panel">

                <h5 class="mb-3">
                    <i class="bi bi-cart3"></i> Keranjang Belanja
                </h5>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= esc(session()->getFlashdata('error')) ?>
                    </div>
                <?php endif; ?>

                <form action="<?= site_url('cashier/store') ?>" method="post" id="checkoutForm">

                    <?= csrf_field() ?>

                    <div id="cartItems">
                        <p class="text-muted text-center py-4">
                            Keranjang masih kosong.
                        </p>
                    </div>

                    <div class="mt-3">

                        <label class="form-label">Nama Pelanggan (Opsional)</label>

                        <input type="text"
                               name="customer_name"
                               class="form-control"
                               placeholder="Nama pelanggan">

                    </div>

                    <div class="mt-3">

                        <label class="form-label">Diskon (Rp)</label>

                        <input type="number"
                               name="discount"
                               id="discount"
                               class="form-control"
                               min="0"
                               value="0"
                               oninput="renderCart()">

                    </div>

                    <hr>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal</span>
                        <strong id="subtotal">Rp 0</strong>
                    </div>

                    <div class="d-flex justify-content-between mb-3">
                        <span>Diskon</span>
                        <strong id="discountText">Rp 0</strong>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <h5>Total Bayar</h5>
                        <div class="money" id="grandTotal">Rp 0</div>
                    </div>

                    <div class="mt-3">

                        <label class="form-label">Metode Pembayaran</label>

                        <select name="payment_method"
                                id="paymentMethod"
                                class="form-select"
                                required
                                onchange="paymentChanged()">

                            <option value="cash">Cash / Tunai</option>
                            <option value="transfer">Transfer</option>
                            <option value="qris">QRIS</option>

                        </select>

                    </div>

                    <div class="mt-3">

                        <label class="form-label">Uang Diterima (Rp)</label>

                        <input type="number"
                               name="paid_amount"
                               id="paidAmount"
                               class="form-control"
                               min="0"
                               value="0"
                               required
                               oninput="renderCart()">

                    </div>

                    <div class="d-flex justify-content-between mt-3">
                        <span>Kembalian</span>
                        <strong id="changeAmount">Rp 0</strong>
                    </div>

                    <div class="form-check form-switch mt-3">
                        <input class="form-check-input" type="checkbox" id="autoDirectPrint" checked>
                        <label class="form-check-label small text-muted" for="autoDirectPrint">
                            Direct print otomatis (58mm) jika printer tersambung
                        </label>
                    </div>

                    <button type="submit"
                            class="btn btn-pink w-100 mt-3"
                            id="checkoutButton">

                        <i class="bi bi-check-circle"></i>
                        Proses Pembayaran

                    </button>

                </form>

                <div id="directPrintResult" class="alert alert-success mt-3 d-none">
                    <div class="fw-bold mb-1" id="directPrintTitle">Transaksi Berhasil!</div>
                    <small class="d-block mb-2" id="directPrintMeta"></small>
                    <div class="d-flex gap-2 flex-wrap">
                        <button type="button" class="btn btn-sm btn-success" id="btnReprintLast">
                            <i class="bi bi-printer"></i> Cetak Ulang 58mm
                        </button>
                        <a href="#" class="btn btn-sm btn-outline-success" id="btnViewLastReceipt">
                            Lihat Nota
                        </a>
                    </div>
                </div>

            </div>

        </div>

    </div>

</div>

<script>
    let cart = [];

    const rupiah = number => {
        return 'Rp ' + Math.round(number).toLocaleString('id-ID');
    };

    function addToCart(id, name, price) {

        const existing = cart.find(item => item.id === id);

        if (existing) {
            existing.quantity++;
        } else {
            cart.push({
                id: id,
                name: name,
                price: price,
                quantity: 1
            });
        }

        renderCart();
    }

    function updateQuantity(id, change) {

        const item = cart.find(item => item.id === id);

        if (!item) return;

        item.quantity += change;

        if (item.quantity <= 0) {
            cart = cart.filter(item => item.id !== id);
        }

        renderCart();
    }

    function renderCart() {

        const container = document.getElementById('cartItems');

        container.innerHTML = '';

        let subtotal = 0;

        cart.forEach(item => {

            const itemTotal = item.price * item.quantity;

            subtotal += itemTotal;

            container.innerHTML += `
                <div class="cart-item">
                    <div class="d-flex justify-content-between gap-2">

                        <div>
                            <strong>${escapeHtml(item.name)}</strong>
                            <br>
                            <small class="text-muted">
                                ${rupiah(item.price)}
                            </small>
                        </div>

                        <div class="text-end">
                            <strong>${rupiah(itemTotal)}</strong>

                            <div class="d-flex align-items-center gap-2 mt-2">
                                <button type="button"
                                        class="btn btn-sm btn-outline-secondary"
                                        onclick="updateQuantity(${item.id}, -1)">
                                    -
                                </button>

                                ${item.quantity}

                                <button type="button"
                                        class="btn btn-sm btn-outline-secondary"
                                        onclick="updateQuantity(${item.id}, 1)">
                                    +
                                </button>
                            </div>
                        </div>

                    </div>

                    <input type="hidden" name="product_id[]" value="${item.id}">
                    <input type="hidden" name="quantity[]" value="${item.quantity}">
                </div>
            `;
        });

        if (cart.length === 0) {
            container.innerHTML = `
                <p class="text-muted text-center py-4">
                    Keranjang masih kosong.
                </p>
            `;
        }

        let discount = Number(document.getElementById('discount').value) || 0;

        discount = Math.max(0, Math.min(discount, subtotal));

        const total = subtotal - discount;

        const paid = Number(document.getElementById('paidAmount').value) || 0;

        const change = Math.max(0, paid - total);

        document.getElementById('subtotal').innerText = rupiah(subtotal);
        document.getElementById('discountText').innerText = rupiah(discount);
        document.getElementById('grandTotal').innerText = rupiah(total);
        document.getElementById('changeAmount').innerText = rupiah(change);

        const discountInput = document.getElementById('discount');

        if (Number(discountInput.value) !== discount) {
            discountInput.value = discount;
        }

        document.getElementById('checkoutButton').disabled =
            cart.length === 0 || paid < total;
    }

    function paymentChanged() {

        const method = document.getElementById('paymentMethod').value;
        const paidInput = document.getElementById('paidAmount');

        if (method !== 'cash') {

            let subtotal = cart.reduce(
                (sum, item) => sum + item.price * item.quantity, 0
            );

            let discount = Number(document.getElementById('discount').value) || 0;

            paidInput.value = Math.max(0, subtotal - discount);
        }

        renderCart();
    }

    function escapeHtml(value) {
        const div = document.createElement('div');
        div.textContent = value;
        return div.innerHTML;
    }

    document.getElementById('searchProduct').addEventListener('input', function() {

        const keyword = this.value.toLowerCase();

        document.querySelectorAll('.product-wrapper').forEach(element => {

            element.style.display =
                element.dataset.name.includes(keyword) ? '' : 'none';

        });

    });

    let lastDirectReceipt = null;

    function toReceiptPayload(resData) {
        const s = resData.sale;
        return {
            orderId: s.invoice_no,
            date: s.created_at,
            customerName: s.customer_name || 'Umum',
            cashier: resData.cashier || '',
            items: (resData.items || []).map(item => ({
                name: item.product_name,
                qty: Number(item.quantity),
                price: Number(item.price),
                subtotal: Number(item.subtotal),
            })),
            subtotal: Number(s.total),
            discount: Number(s.discount),
            total: Number(s.grand_total),
            paymentMethod: s.payment_method,
            paid: Number(s.paid_amount),
            change: Number(s.change_amount),
        };
    }

    document.getElementById('btnReprintLast').addEventListener('click', async function() {
        if (!lastDirectReceipt || !window.BoquetPrinter) return;
        try {
            if (!window.BoquetPrinter.isConnected()) {
                const info = await window.BoquetPrinter.scanAndConnect('all');
                if (!info) return;
            }
            await window.BoquetPrinter.printSaleReceipt(lastDirectReceipt);
        } catch (err) {
            window.BoquetPrinter.showToast(err.message, 'error');
        }
    });

    document.getElementById('checkoutForm').addEventListener('submit', async function(e) {

        if (cart.length === 0) {
            e.preventDefault();
            alert('Keranjang masih kosong!');
            return;
        }

        if (!confirm('Yakin ingin memproses transaksi ini?')) {
            e.preventDefault();
            return;
        }

        const useDirectPrint =
            document.getElementById('autoDirectPrint').checked &&
            window.BoquetPrinter &&
            window.BoquetPrinter.isConnected();

        if (!useDirectPrint) {
            return; // Normal form submit -> redirect to /cashier/success/{id}
        }

        e.preventDefault();

        const form = this;
        const btn = document.getElementById('checkoutButton');
        const originalHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = 'Memproses &amp; Mencetak...';

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: new FormData(form)
            });

            const data = await response.json();

            if (data.csrf_name && data.csrf_hash) {
                const csrfInput = form.querySelector(`input[name="${data.csrf_name}"]`);
                if (csrfInput) csrfInput.value = data.csrf_hash;
            }

            if (!response.ok || data.status !== 'ok') {
                throw new Error(data.message || 'Transaksi gagal diproses.');
            }

            lastDirectReceipt = toReceiptPayload(data);

            const resultBox = document.getElementById('directPrintResult');
            const resultTitle = document.getElementById('directPrintTitle');
            const resultMeta = document.getElementById('directPrintMeta');
            const viewLink = document.getElementById('btnViewLastReceipt');

            resultBox.classList.remove('d-none', 'alert-warning');
            resultBox.classList.add('alert-success');
            resultTitle.textContent = `Transaksi ${data.sale.invoice_no} Berhasil!`;
            resultMeta.textContent = `Total ${rupiah(data.sale.grand_total)} • Kembalian ${rupiah(data.sale.change_amount)}`;
            viewLink.href = data.redirect_url;

            cart = [];
            form.querySelector('input[name="customer_name"]').value = '';
            document.getElementById('discount').value = 0;
            document.getElementById('paidAmount').value = 0;
            document.getElementById('paymentMethod').value = 'cash';
            renderCart();

            try {
                await window.BoquetPrinter.printSaleReceipt(lastDirectReceipt);
            } catch (printErr) {
                resultBox.classList.remove('alert-success');
                resultBox.classList.add('alert-warning');
                resultMeta.textContent += ' (Gagal cetak: ' + printErr.message + ')';
                window.BoquetPrinter.showToast('Transaksi tersimpan, tetapi cetak gagal: ' + printErr.message, 'error');
            }
        } catch (err) {
            alert(err.message);
        } finally {
            btn.disabled = cart.length === 0;
            btn.innerHTML = originalHtml;
            renderCart();
        }
    });

    renderCart();
</script>

<?= view('partials/printer_scanner', ['autoReconnectPrinter' => true]) ?>

</body>
</html>