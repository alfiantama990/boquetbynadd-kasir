/**
 * EscPosBuilder - Lightweight, zero-dependency ESC/POS command builder
 * Default configured for 58mm (32 chars) thermal printers, also supports 80mm (48 chars).
 */
export class EscPosBuilder {
  static ESC = 0x1b;
  static GS = 0x1d;
  static LF = 0x0a;

  constructor(paperWidthMm = 58) {
    this.paperWidthMm = paperWidthMm === 80 ? 80 : 58;
    this.charsPerLine = this.paperWidthMm === 80 ? 48 : 32;
    this.buffer = [];
    this.encoder = new TextEncoder();
  }

  /**
   * Append raw bytes to the command buffer.
   * @param {number[]|Uint8Array} bytes
   */
  raw(bytes) {
    for (const b of bytes) {
      this.buffer.push(b & 0xff);
    }
    return this;
  }

  /**
   * Initialize printer (ESC @).
   */
  init() {
    return this.raw([EscPosBuilder.ESC, 0x40]);
  }

  /**
   * Set text alignment: 'left' | 'center' | 'right'.
   */
  align(mode = 'left') {
    const map = { left: 0, center: 1, right: 2 };
    const n = map[mode] ?? 0;
    return this.raw([EscPosBuilder.ESC, 0x61, n]);
  }

  /**
   * Toggle bold text (ESC E n).
   */
  bold(enabled = true) {
    return this.raw([EscPosBuilder.ESC, 0x45, enabled ? 1 : 0]);
  }

  /**
   * Set underline mode: 0 = off, 1 = 1-dot, 2 = 2-dot (ESC - n).
   */
  underline(mode = 1) {
    const n = Math.max(0, Math.min(2, Number(mode) || 0));
    return this.raw([EscPosBuilder.ESC, 0x2d, n]);
  }

  /**
   * Toggle white/black reverse printing (GS B n).
   */
  invert(enabled = true) {
    return this.raw([EscPosBuilder.GS, 0x42, enabled ? 1 : 0]);
  }

  /**
   * Set character size multiplier (1..8 for width and height) (GS ! n).
   */
  size(widthMul = 1, heightMul = 1) {
    const w = Math.max(1, Math.min(8, widthMul)) - 1;
    const h = Math.max(1, Math.min(8, heightMul)) - 1;
    return this.raw([EscPosBuilder.GS, 0x21, (w << 4) | h]);
  }

  /**
   * Normalize characters to printable ASCII so budget thermal printers
   * do not output garbled glyphs.
   */
  static sanitizeText(str) {
    return String(str ?? '')
      .replace(/[“”]/g, '"')
      .replace(/[‘’]/g, "'")
      .replace(/[–—]/g, '-')
      .replace(/\u00a0/g, ' ')
      .normalize('NFKD')
      .replace(/[^\x20-\x7E\n\r\t]/g, '');
  }

  /**
   * Write text without trailing newline.
   */
  text(str) {
    const clean = EscPosBuilder.sanitizeText(str);
    return this.raw(this.encoder.encode(clean));
  }

  /**
   * Write text followed by a newline.
   */
  line(str = '') {
    return this.text(str).raw([EscPosBuilder.LF]);
  }

  /**
   * Print a horizontal divider line matching paper width.
   */
  hr(char = '-') {
    return this.line(char.repeat(this.charsPerLine));
  }

  /**
   * Print two-column line (left-aligned label, right-aligned value).
   */
  row(left, right) {
    const l = EscPosBuilder.sanitizeText(left);
    const r = EscPosBuilder.sanitizeText(right);
    const maxCols = this.charsPerLine;

    if (l.length + r.length + 1 <= maxCols) {
      const spaces = ' '.repeat(maxCols - l.length - r.length);
      return this.line(l + spaces + r);
    }

    const availableLeft = Math.max(8, maxCols - r.length - 1);
    const firstPart = l.slice(0, availableLeft);
    const rest = l.slice(availableLeft);
    const spaces = ' '.repeat(Math.max(1, maxCols - firstPart.length - r.length));
    this.line(firstPart + spaces + r);

    if (rest.trim().length > 0) {
      this.line(rest.trim());
    }
    return this;
  }

  /**
   * Feed N blank lines (ESC d n).
   */
  feed(lines = 3) {
    const n = Math.max(0, Math.min(255, lines));
    return this.raw([EscPosBuilder.ESC, 0x64, n]);
  }

  /**
   * Cut paper (GS V m). Portable 58mm printers without auto-cutter safely ignore this.
   */
  cut(partial = true) {
    return this.raw([EscPosBuilder.GS, 0x56, partial ? 1 : 0]);
  }

  /**
   * Kick RJ11 cash drawer (ESC p).
   */
  openDrawer() {
    return this.raw([EscPosBuilder.ESC, 0x70, 0x00, 0x19, 0xfa]);
  }

  /**
   * Print a QR Code using standard ESC/POS GS ( k commands.
   */
  qrCode(data, moduleSize = 6) {
    const payload = this.encoder.encode(String(data ?? ''));
    const len = payload.length + 3;
    const pL = len & 0xff;
    const pH = (len >> 8) & 0xff;
    const size = Math.max(1, Math.min(16, moduleSize));

    this.raw([EscPosBuilder.GS, 0x28, 0x6b, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00]);
    this.raw([EscPosBuilder.GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x43, size]);
    this.raw([EscPosBuilder.GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x45, 0x30]);
    this.raw([EscPosBuilder.GS, 0x28, 0x6b, pL, pH, 0x31, 0x50, 0x30]);
    this.raw(payload);
    this.raw([EscPosBuilder.GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30]);
    return this;
  }

  /**
   * Return compiled ESC/POS byte array.
   */
  build() {
    return new Uint8Array(this.buffer);
  }

  /**
   * Format currency in Indonesian Rupiah style without non-ASCII characters.
   */
  static formatRp(amount) {
    const num = Math.round(Number(amount) || 0);
    return 'Rp ' + num.toLocaleString('id-ID').replace(/,/g, '.');
  }

  /**
   * Build a standard POS receipt (default 58mm / 32 columns).
   */
  static buildReceipt(receipt, paperWidthMm = 58) {
    const b = new EscPosBuilder(paperWidthMm);
    b.init();

    // Header
    b.align('center')
      .bold(true)
      .size(1, 2)
      .line(receipt.storeName || 'BoquetBaloon')
      .size(1, 1)
      .bold(false);

    if (receipt.subtitle) b.line(receipt.subtitle);
    if (receipt.address) b.line(receipt.address);
    if (receipt.phone) b.line(`Telp: ${receipt.phone}`);

    b.align('left').hr('-');

    if (receipt.orderId) b.row('Invoice', receipt.orderId);
    if (receipt.date) b.row('Tanggal', receipt.date);
    if (receipt.customerName) b.row('Pelanggan', receipt.customerName);
    if (receipt.cashier) b.row('Kasir', receipt.cashier);

    b.hr('-');

    // Items
    for (const item of receipt.items || []) {
      const qty = Number(item.qty ?? item.quantity) || 1;
      const price = Number(item.price) || 0;
      const lineTotal = item.subtotal != null ? Number(item.subtotal) : qty * price;
      b.line(item.name || item.product_name || 'Item');
      b.row(`  ${qty} x ${EscPosBuilder.formatRp(price)}`, EscPosBuilder.formatRp(lineTotal));
    }

    b.hr('-');

    if (receipt.subtotal != null) {
      b.row('Subtotal', EscPosBuilder.formatRp(receipt.subtotal));
    }
    if (Number(receipt.discount) > 0) {
      b.row('Diskon', '-' + EscPosBuilder.formatRp(receipt.discount));
    }

    b.bold(true)
      .row('TOTAL', EscPosBuilder.formatRp(receipt.total))
      .bold(false);

    if (receipt.paymentMethod) {
      b.row('Metode', String(receipt.paymentMethod).toUpperCase());
    }
    if (receipt.paid != null) {
      b.row('Dibayar', EscPosBuilder.formatRp(receipt.paid));
      const change = receipt.change != null
        ? Math.max(0, Number(receipt.change))
        : Math.max(0, Number(receipt.paid) - Number(receipt.total));
      b.row('Kembali', EscPosBuilder.formatRp(change));
    }

    b.hr('=');
    b.align('center');
    if (receipt.footer) {
      for (const line of String(receipt.footer).split('\n')) {
        b.line(line);
      }
    } else {
      b.line('Terima kasih sudah berbelanja!');
      b.line('BoquetBaloon POS');
    }

    if (receipt.qrData) {
      b.feed(1).qrCode(receipt.qrData, 5).feed(1);
    }

    b.feed(4).cut(true);
    return b.build();
  }
}
